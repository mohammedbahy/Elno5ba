const fs = require('fs');
const path = require('path');

const usersFile = path.join(__dirname, '../models/users.json');

// Helper to read users
function readUsers() {
  if (!fs.existsSync(usersFile)) return [];
  try {
    const data = fs.readFileSync(usersFile, 'utf8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

// Helper to write users
function writeUsers(users) {
  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2), 'utf8');
}

exports.register = (req, res) => {
  const { email, password, role } = req.body;
  if (!email || !password || !role) {
    return res.status(400).json({ error: 'يرجى إدخال جميع البيانات.' });
  }
  const users = readUsers();
  if (users.find(u => u.email === email)) {
    return res.status(409).json({ error: 'البريد الإلكتروني مستخدم بالفعل.' });
  }
  const newUser = { email, password, role };
  users.push(newUser);
  writeUsers(users);
  res.json({ success: true, user: newUser });
};

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

exports.login = (req, res) => {
  const { email, password } = req.body;
  const users = readUsers();

  const user = users.find(u => u.email === email || u.phone === email); // السماح بالإيميل أو رقم الهاتف
  if (!user) {
    return res.status(401).json({ error: 'المستخدم غير موجود' });
  }

  bcrypt.compare(password, user.password, (err, isMatch) => {
    if (err || !isMatch) {
      return res.status(401).json({ error: 'كلمة السر غير صحيحة' });
    }

    // نجاح: إصدار توكن (اختياري)
    const token = jwt.sign({ email: user.email, role: user.role }, 'mySecretKey', { expiresIn: '1h' });

    res.json({ success: true, token, user: { email: user.email, role: user.role } });
  });
};

