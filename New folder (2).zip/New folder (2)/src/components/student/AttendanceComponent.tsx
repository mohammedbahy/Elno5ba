import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Calendar, CheckCircle, XCircle, Check } from "lucide-react";
import { useMemo, useState } from "react";

// بيانات حضور تجريبية
const mockAttendance = [
	{ id: 1, date: "2025-07-15", status: "حاضر", subject: "رياضيات" },
	{ id: 2, date: "2025-07-16", status: "حاضر", subject: "علوم" },
	{ id: 3, date: "2025-07-17", status: "غائب", subject: "تاريخ" },
	{ id: 4, date: "2025-07-18", status: "حاضر", subject: "رياضيات" },
	{ id: 5, date: "2025-07-19", status: "حاضر", subject: "علوم" },
	{ id: 6, date: "2025-07-20", status: "حاضر", subject: "تاريخ" },
	{ id: 7, date: "2025-07-21", status: "حاضر", subject: "رياضيات" },
];
const attendanceStats = {
	present: 6,
	absent: 1,
	percentage: 85.7,
	month: "يوليو 2025",
};
const days = [
	{ day: "السبت", date: 15, status: "حاضر" },
	{ day: "الأحد", date: 16, status: "حاضر" },
	{ day: "الإثنين", date: 17, status: "غائب" },
	{ day: "الثلاثاء", date: 18, status: "حاضر" },
	{ day: "الأربعاء", date: 19, status: "حاضر" },
	{ day: "الخميس", date: 20, status: "حاضر" },
	{ day: "الجمعة", date: 21, status: "حاضر" },
];

// توليد أيام الشهر مع حالة الحضور
function generateMonthDays() {
	// يوليو 2025 يبدأ الثلاثاء (1 يوليو 2025 هو الثلاثاء)
	const monthDays = [];
	const totalDays = 31;
	const firstDayOfWeek = 2; // الثلاثاء (0=الأحد)
	let dayIndex = 0;
	for (let i = 0; i < firstDayOfWeek; i++) {
		monthDays.push(null); // أيام فارغة قبل بداية الشهر
	}
	for (let d = 1; d <= totalDays; d++) {
		// ابحث عن حالة اليوم في days
		const found = days.find((dayObj) => dayObj.date === d);
		monthDays.push({
			date: d,
			day: found ? found.day : null,
			status: found ? found.status : null,
		});
		dayIndex++;
	}
	// أكمل الصف الأخير حتى 7 أعمدة
	while (monthDays.length % 7 !== 0) {
		monthDays.push(null);
	}
	return monthDays;
}

// بيانات مهام السنة الدراسية (مثال)
const yearTasks = [
	{
		month: "يوليو",
		days: [
			{ day: 1, task: "حضور" },
			{ day: 5, task: "امتحان" },
			{ day: 10, task: "واجب" },
			{ day: 15, task: "حضور" },
			{ day: 20, task: "حضور" },
			{ day: 25, task: "امتحان" },
		],
	},
	{
		month: "أغسطس",
		days: [
			{ day: 2, task: "حضور" },
			{ day: 8, task: "واجب" },
			{ day: 12, task: "امتحان" },
			{ day: 18, task: "حضور" },
			{ day: 22, task: "حضور" },
			{ day: 29, task: "واجب" },
		],
	},
	// ...يمكنك إضافة باقي الشهور بنفس النمط...
];

export default function AttendanceComponent() {
	const presentCount = mockAttendance.filter((a) => a.status === "حاضر").length;
	const absentCount = mockAttendance.filter((a) => a.status === "غائب").length;
	const attendanceRate = ((presentCount / (presentCount + absentCount)) * 100).toFixed(1);
	const now = new Date();
	// ترتيب المحاضرات حسب التاريخ
	const lecturesArray = useMemo(() => {
		return mockAttendance
			.map((a) => ({
				day: new Date(a.date + "T00:00:00Z").getUTCDate(),
				status: a.status,
				date: a.date,
			}))
			.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
	}, []);
	const weekDays = ["السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"];
	const monthDays = generateMonthDays();
	const weekNames = ["الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
	const [openYearDialog, setOpenYearDialog] = useState(false);

	return (
		<div
			className="min-h-screen px-2 md:px-8 py-6 font-[Cairo,Tajawal,sans-serif] space-y-6"
			dir="rtl"
			style={{
				background:
					"linear-gradient(120deg, #f1f5fe 0%, #e0e7ff 60%, #fbc2eb 100%)",
			}}
		>
			<div className="flex items-center justify-between mb-4">
				<h2 className="text-3xl font-extrabold tracking-tight flex items-center gap-2 text-indigo-800 drop-shadow">
					<Calendar
						className="text-pink-500 bg-pink-100 rounded-full p-1"
						size={32}
					/>
					سجل الحضور
				</h2>
				<div>
					<Dialog>
						<DialogTrigger asChild>
							<Button className="bg-edu-pink hover:bg-edu-pink/90 btn-animate">
								تسجيل حضور اليوم
							</Button>
						</DialogTrigger>
						<DialogContent>
							<DialogHeader>
								<DialogTitle>
									تسجيل الحضور ليوم{" "}
									{now.toLocaleDateString("ar-EG", {
										day: "numeric",
										month: "long",
										year: "numeric",
									})}
								</DialogTitle>
								<DialogDescription>
									يرجى تأكيد حضورك لحصص اليوم.
								</DialogDescription>
							</DialogHeader>
							<div className="space-y-4 py-4">
								<div className="rounded-lg border p-4">
									<div className="flex items-center justify-between">
										<div>
											<h4 className="font-medium">أساسيات الفيزياء</h4>
											<p className="text-sm text-muted-foreground">
												علوم • 10:00 ص - 10:55 ص
											</p>
										</div>
										<Button
											size="sm"
											className="bg-green-500 hover:bg-green-600 btn-animate"
										>
											<Check className="mr-2 h-4 w-4" />
											حاضر
										</Button>
									</div>
								</div>
							</div>
							<DialogFooter>
								<Button
									variant="outline"
									className="btn-animate"
								>
									إلغاء
								</Button>
								<Button className="bg-edu-pink hover:bg-edu-pink/90 btn-animate">
									تأكيد الحضور
								</Button>
							</DialogFooter>
						</DialogContent>
					</Dialog>
				</div>
			</div>

			{/* بطاقة الإحصائيات */}
			<div className="bg-gradient-to-br from-white via-indigo-50 to-pink-50 rounded-2xl shadow-xl border border-indigo-100 p-6 mb-6 flex flex-col md:flex-row items-center justify-between gap-6">
				<div className="flex flex-col items-center gap-2">
					<span className="text-lg font-bold text-green-700 flex items-center gap-1">
						<CheckCircle className="text-green-500" size={20} /> حاضر:{" "}
						{attendanceStats.present}
					</span>
					<span className="text-lg font-bold text-pink-700 flex items-center gap-1">
						<XCircle className="text-pink-500" size={20} /> غائب:{" "}
						{attendanceStats.absent}
					</span>
				</div>
				<div className="flex flex-col items-center gap-2">
					<span className="text-xl font-extrabold text-indigo-800">
						إحصائيات الشهر الحالي
					</span>
					<span className="text-purple-600 font-bold">
						{attendanceStats.month}
					</span>
					<div className="flex items-center gap-2 mt-2">
						<span className="text-2xl font-extrabold text-green-600">
							{attendanceStats.percentage}%
						</span>
						<span className="text-sm text-gray-500">نسبة الحضور</span>
					</div>
					<div className="w-40 h-2 rounded bg-yellow-100 mt-2 overflow-hidden">
						<div
							className="h-2 rounded bg-green-400 transition-all"
							style={{ width: `${attendanceStats.percentage}%` }}
						></div>
					</div>
				</div>
			</div>
			{/* جدول الأيام */}
			<div className="bg-gradient-to-br from-white via-purple-50 to-pink-50 rounded-2xl shadow-xl border border-purple-100 p-6">
				<div className="flex items-center justify-between mb-4">
					<h3 className="text-xl font-extrabold text-indigo-800 flex items-center gap-2">
						<Calendar className="text-pink-500" size={22} />
						تقويم الحضور لشهر {attendanceStats.month}
					</h3>
				</div>
				<div className="overflow-x-auto">
					<table className="w-full text-center">
						<thead>
							<tr>
								{weekNames.map((w, idx) => (
									<th key={idx} className="pb-2 text-indigo-700 font-bold">{w}</th>
								))}
							</tr>
						</thead>
						<tbody>
							{Array.from({ length: monthDays.length / 7 }).map((_, rowIdx) => (
								<tr key={rowIdx}>
									{monthDays.slice(rowIdx * 7, rowIdx * 7 + 7).map((day, colIdx) =>
										day ? (
											<td key={colIdx} className="p-2">
												<div
													className={`flex flex-col items-center justify-center rounded-xl shadow transition-all duration-150 hover:scale-105 border
                            ${day.status === "حاضر"
														? "bg-green-50 border-green-200"
														: day.status === "غائب"
															? "bg-pink-50 border-pink-200"
															: "bg-gray-50 border-gray-200"
													}`}
													style={{ minWidth: 70, minHeight: 70 }}
												>
													<span className="font-bold text-indigo-700">{day.date}</span>
													{day.status && (
														<span
															className={`mt-2 px-3 py-1 rounded-full text-xs font-bold shadow
                                ${day.status === "حاضر"
																? "bg-green-200 text-green-800"
																: "bg-pink-200 text-pink-800"
															}`}
														>
															{day.status}
														</span>
													)}
												</div>
											</td>
										) : (
											<td key={colIdx} className="p-2">
												{/* يوم فارغ */}
											</td>
										)
									)}
								</tr>
							))}
						</tbody>
					</table>
				</div>
			</div>
		</div>
	);
}