import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Calendar, FileText } from "lucide-react";

// Mock data
const mockExams = [
	{ id: 1, title: "Algebra Mid-term", subject: "Mathematics", date: "2025-07-25", status: "Upcoming" },
	{ id: 2, title: "Physics Concepts", subject: "Science", date: "2025-07-28", status: "Upcoming" },
	{ id: 3, title: "History Quiz", subject: "History", date: "2025-07-15", status: "Completed", score: 85 },
	{ id: 4, title: "Science Lab Test", subject: "Science", date: "2025-07-10", status: "Completed", score: 92 },
];

export default function ExamsComponent() {
	return (
		<div
			className="space-y-6 font-[Cairo,Tajawal,sans-serif] min-h-screen px-2 md:px-8 py-6"
			dir="rtl"
			style={{
				background:
					"linear-gradient(120deg, #f1f5fe 0%, #e0e7ff 60%, #fbc2eb 100%)",
			}}
		>
			<div className="flex items-center justify-between mb-2">
				<h2 className="text-3xl font-extrabold tracking-tight flex items-center gap-2 text-indigo-800 drop-shadow">
					<FileText className="text-pink-500 bg-pink-100 rounded-full p-1" size={32} />
					الامتحانات
				</h2>
			</div>
			<div className="grid gap-6 md:grid-cols-2">
				<Card className="bg-gradient-to-br from-white via-indigo-50 to-pink-50 rounded-2xl shadow-xl border border-indigo-100">
					<CardHeader className="pb-3">
						<CardTitle className="text-xl font-extrabold text-indigo-800">
							الامتحانات القادمة
						</CardTitle>
						<CardDescription className="text-purple-600 font-bold">
							الامتحانات المجدولة خلال 30 يوماً القادمة
						</CardDescription>
					</CardHeader>
					<CardContent>
						<div className="space-y-4">
							{mockExams
								.filter((e) => e.status === "Upcoming")
								.map((exam) => (
									<div
										key={exam.id}
										className="flex items-center gap-4 bg-gradient-to-r from-pink-50 via-purple-50 to-indigo-50 rounded-xl p-3 shadow hover:scale-[1.02] transition-all duration-150 border border-pink-100"
									>
										<div className="bg-pink-100 p-3 rounded-full shadow">
											<FileText className="h-6 w-6 text-pink-500" />
										</div>
										<div className="flex-1 space-y-1">
											<p className="font-bold text-indigo-800">
												{exam.title === "Algebra Mid-term"
													? "امتحان منتصف الفصل للجبر"
													: exam.title === "Physics Concepts"
													? "مفاهيم الفيزياء"
													: exam.title === "History Quiz"
													? "امتحان تاريخ"
													: exam.title}
											</p>
											<div className="flex items-center text-sm text-muted-foreground gap-2">
												<Badge className="bg-yellow-100 text-yellow-700 border border-yellow-200 font-bold">
													{exam.subject === "Mathematics"
														? "رياضيات"
														: exam.subject === "Science"
														? "علوم"
														: exam.subject === "History"
														? "تاريخ"
														: exam.subject}
												</Badge>
												<Calendar className="h-4 w-4 text-purple-400" />{" "}
												{exam.date}
											</div>
										</div>
										<Button className="bg-gradient-to-r from-pink-400 to-purple-500 text-white font-bold shadow hover:brightness-110 btn-animate">
											استعد
										</Button>
									</div>
								))}
						</div>
					</CardContent>
				</Card>

				<Card className="bg-gradient-to-br from-white via-pink-50 to-indigo-50 rounded-2xl shadow-xl border border-pink-100">
					<CardHeader className="pb-3">
						<CardTitle className="text-xl font-extrabold text-indigo-800">
							نتائج الامتحانات السابقة
						</CardTitle>
						<CardDescription className="text-purple-600 font-bold">
							أداؤك في الامتحانات السابقة
						</CardDescription>
					</CardHeader>
					<CardContent>
						<div className="space-y-4">
							{mockExams
								.filter((e) => e.status === "Completed")
								.map((exam) => (
									<div
										key={exam.id}
										className="border rounded-xl p-4 bg-gradient-to-r from-white via-yellow-50 to-pink-50 shadow hover:scale-[1.01] transition-all duration-150 border-yellow-100"
									>
										<div className="flex items-center justify-between">
											<div>
												<p className="font-bold text-indigo-800">
													{exam.title === "Algebra Mid-term"
														? "امتحان منتصف الفصل للجبر"
														: exam.title === "Physics Concepts"
														? "مفاهيم الفيزياء"
														: exam.title === "History Quiz"
														? "امتحان تاريخ"
														: exam.title}
												</p>
												<div className="flex items-center text-sm text-muted-foreground gap-2">
													<Badge className="bg-yellow-100 text-yellow-700 border border-yellow-200 font-bold">
														{exam.subject === "Mathematics"
															? "رياضيات"
															: exam.subject === "Science"
															? "علوم"
															: exam.subject === "History"
															? "تاريخ"
															: exam.subject}
													</Badge>
													<Calendar className="h-4 w-4 text-purple-400" />{" "}
													{exam.date}
												</div>
											</div>
											<div className="text-center">
												<div className="text-2xl font-extrabold text-orange-500">
													{exam.score}%
												</div>
												<div className="text-xs text-gray-500 font-bold">
													الدرجة
												</div>
											</div>
										</div>
										<div className="mt-4">
											<div className="flex items-center justify-between mb-1 text-xs font-bold text-gray-500">
												<span>٠٪</span>
												<span>١٠٠٪</span>
											</div>
											<Progress value={exam.score} className="h-2 bg-yellow-100" />
										</div>
									</div>
								))}
						</div>
					</CardContent>
				</Card>
			</div>

			<Card className="bg-gradient-to-br from-white via-indigo-50 to-pink-50 rounded-2xl shadow-xl border border-indigo-100">
				<CardHeader>
					<CardTitle className="text-xl font-extrabold text-indigo-800">
						مواد للمذاكرة
					</CardTitle>
					<CardDescription className="text-purple-600 font-bold">
						مصادر تساعدك في الاستعداد للامتحانات
					</CardDescription>
				</CardHeader>
				<CardContent>
					<div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
						<div className="border rounded-xl p-4 hover:border-pink-400 hover:shadow-xl transition-all bg-gradient-to-br from-white via-yellow-50 to-pink-50">
							<div className="flex items-center justify-between">
								<div className="bg-yellow-100 p-2 rounded-full shadow">
									<FileText className="h-5 w-5 text-yellow-700" />
								</div>
								<Badge className="bg-yellow-100 text-yellow-700 font-bold">
									PDF
								</Badge>
							</div>
							<div className="mt-3">
								<p className="font-bold text-indigo-800">ورقة معادلات الجبر</p>
								<p className="text-xs text-gray-500 mt-1 font-bold">
									رياضيات • تم التحديث قبل ٣ أيام
								</p>
							</div>
							<Button
								variant="outline"
								className="w-full mt-3 border-pink-400 text-pink-700 hover:bg-pink-50 font-bold btn-animate"
							>
								تحميل
							</Button>
						</div>

						<div className="border rounded-xl p-4 hover:border-pink-400 hover:shadow-xl transition-all bg-gradient-to-br from-white via-yellow-50 to-pink-50">
							<div className="flex items-center justify-between">
								<div className="bg-yellow-100 p-2 rounded-full shadow">
									<FileText className="h-5 w-5 text-yellow-700" />
								</div>
								<Badge className="bg-yellow-100 text-yellow-700 font-bold">
									PDF
								</Badge>
							</div>
							<div className="mt-3">
								<p className="font-bold text-indigo-800">ورقة ملخص الفيزياء</p>
								<p className="text-xs text-gray-500 mt-1 font-bold">
									علوم • تم التحديث قبل أسبوع
								</p>
							</div>
							<Button
								variant="outline"
								className="w-full mt-3 border-pink-400 text-pink-700 hover:bg-pink-50 font-bold btn-animate"
							>
								تحميل
							</Button>
						</div>

						<div className="border rounded-xl p-4 hover:border-pink-400 hover:shadow-xl transition-all bg-gradient-to-br from-white via-yellow-50 to-pink-50">
							<div className="flex items-center justify-between">
								<div className="bg-yellow-100 p-2 rounded-full shadow">
									<FileText className="h-5 w-5 text-yellow-700" />
								</div>
								<Badge className="bg-yellow-100 text-yellow-700 font-bold">
									PDF
								</Badge>
							</div>
							<div className="mt-3">
								<p className="font-bold text-indigo-800">الخط الزمني للتاريخ</p>
								<p className="text-xs text-gray-500 mt-1 font-bold">
									تاريخ • تم التحديث قبل أسبوعين
								</p>
							</div>
							<Button
								variant="outline"
								className="w-full mt-3 border-pink-400 text-pink-700 hover:bg-pink-50 font-bold btn-animate"
							>
								تحميل
							</Button>
						</div>
					</div>
				</CardContent>
			</Card>
		</div>
	);
}