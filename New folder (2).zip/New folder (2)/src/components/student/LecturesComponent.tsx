import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Video, Calendar, Clock, Check } from "lucide-react";

// Mock data
const mockLectures = [
	{
		id: 1,
		title: "Introduction to Mathematics",
		subject: "Mathematics",
		duration: "45 minutes",
		date: "2025-07-20",
		completed: true,
	},
	{
		id: 2,
		title: "Advanced Algebra Concepts",
		subject: "Mathematics",
		duration: "60 minutes",
		date: "2025-07-21",
		completed: true,
	},
	{
		id: 3,
		title: "Physics Fundamentals",
		subject: "Science",
		duration: "55 minutes",
		date: "2025-07-22",
		completed: false,
	},
	{
		id: 4,
		title: "Chemical Reactions",
		subject: "Science",
		duration: "50 minutes",
		date: "2025-07-23",
		completed: false,
	},
	{
		id: 5,
		title: "World History Overview",
		subject: "History",
		duration: "65 minutes",
		date: "2025-07-24",
		completed: false,
	},
];

export default function LecturesComponent() {
	return (
		<div
			className="space-y-6 font-[Cairo,Tajawal,sans-serif] min-h-screen px-2 md:px-8 py-6"
			dir="rtl"
			style={{
				background:
					"linear-gradient(120deg, #f1f5fe 0%, #e0e7ff 60%, #fbc2eb 100%)",
			}}
		>
			<div className="flex items-center justify-between mb-2">
				<h2 className="text-3xl font-extrabold tracking-tight flex items-center gap-2 text-indigo-800 drop-shadow">
					<Video className="text-pink-500 bg-pink-100 rounded-full p-1" size={32} />
					المحاضرات
				</h2>
			</div>
			<Tabs defaultValue="all" className="w-full">
				<TabsList className="grid w-full grid-cols-2 bg-gradient-to-r from-indigo-100 via-purple-100 to-pink-100 rounded-xl shadow mb-4">
					<TabsTrigger value="all" className="font-bold text-indigo-700">
						كل المحاضرات
					</TabsTrigger>
					<TabsTrigger value="completed" className="font-bold text-purple-700">
						المكتملة
					</TabsTrigger>
				</TabsList>
				<TabsContent value="all" className="space-y-6 mt-4">
					{mockLectures.map((lecture) => (
						<Card
							key={lecture.id}
							className={`transition-all duration-200 hover:scale-[1.02] hover:shadow-2xl border-none bg-gradient-to-br from-white via-indigo-50 to-pink-50 shadow-xl`}
							style={{
								borderRight: `6px solid ${
									lecture.completed ? "#22c55e" : "#f43f5e"
								}`,
							}}
						>
							<CardHeader className="py-3">
								<div className="flex items-center justify-between">
									<div>
										<CardTitle className="text-lg flex items-center gap-2 text-indigo-800 font-extrabold">
											<Video className="text-pink-500 bg-pink-100 rounded-full p-1" size={22} />
											{lecture.title === "Introduction to Mathematics"
												? "مقدمة في الرياضيات"
												: lecture.title === "Advanced Algebra Concepts"
												? "مفاهيم الجبر المتقدمة"
												: lecture.title === "Physics Fundamentals"
												? "أساسيات الفيزياء"
												: lecture.title === "Chemical Reactions"
												? "التفاعلات الكيميائية"
												: lecture.title === "World History Overview"
												? "نظرة عامة على تاريخ العالم"
												: lecture.title}
										</CardTitle>
										<CardDescription className="text-purple-600 font-bold">
											{lecture.subject} • {lecture.duration}
										</CardDescription>
									</div>
									{lecture.completed ? (
										<Badge className="bg-green-100 text-green-800 border border-green-300 shadow font-bold flex items-center gap-1">
											<Check className="h-4 w-4" /> مكتملة
										</Badge>
									) : (
										<Badge className="bg-pink-100 text-pink-700 border border-pink-300 shadow font-bold">
											قيد الانتظار
										</Badge>
									)}
								</div>
							</CardHeader>
							<CardContent className="py-0">
								<div className="flex items-center gap-2 text-xs text-gray-500 font-bold">
									<Calendar className="text-purple-400" size={16} />
									تاريخ المحاضرة: {lecture.date}
									<Clock className="text-indigo-400" size={16} />
									المدة: {lecture.duration}
								</div>
							</CardContent>
							<CardFooter className="py-3">
								<Button
									className={`rounded-xl font-bold shadow-lg transition-all duration-150 ${
										lecture.completed
											? "bg-gradient-to-r from-green-400 to-green-600 text-white hover:brightness-110"
											: "bg-gradient-to-r from-pink-400 to-purple-500 text-white hover:brightness-110"
									}`}
								>
									<Video className="mr-2 h-4 w-4" />
									{lecture.completed ? "مشاهدة مرة أخرى" : "مشاهدة الآن"}
								</Button>
							</CardFooter>
						</Card>
					))}
				</TabsContent>
				<TabsContent value="completed" className="space-y-6 mt-4">
					{mockLectures
						.filter((l) => l.completed)
						.map((lecture) => (
							<Card
								key={lecture.id}
								className="transition-all duration-200 hover:scale-[1.02] hover:shadow-2xl border-none bg-gradient-to-br from-white via-green-50 to-indigo-50 shadow-xl"
								style={{
									borderRight: "6px solid #22c55e",
								}}
							>
								<CardHeader className="py-3">
									<div className="flex items-center justify-between">
										<div>
											<CardTitle className="text-lg flex items-center gap-2 text-indigo-800 font-extrabold">
												<Video className="text-green-500 bg-green-100 rounded-full p-1" size={22} />
												{lecture.title === "Introduction to Mathematics"
													? "مقدمة في الرياضيات"
													: lecture.title === "Advanced Algebra Concepts"
													? "مفاهيم الجبر المتقدمة"
													: lecture.title}
											</CardTitle>
											<CardDescription className="text-green-700 font-bold">
												{lecture.subject} • {lecture.duration}
											</CardDescription>
										</div>
										<Badge className="bg-green-100 text-green-800 border border-green-300 shadow font-bold flex items-center gap-1">
											<Check className="h-4 w-4" /> مكتملة
										</Badge>
									</div>
								</CardHeader>
								<CardContent className="py-0">
									<div className="flex items-center gap-2 text-xs text-gray-500 font-bold">
										<Calendar className="text-green-400" size={16} />
										تاريخ المحاضرة: {lecture.date}
										<Clock className="text-green-400" size={16} />
										المدة: {lecture.duration}
									</div>
								</CardContent>
								<CardFooter className="py-3">
									<Button className="rounded-xl font-bold shadow-lg bg-gradient-to-r from-green-400 to-green-600 text-white hover:brightness-110">
										<Video className="mr-2 h-4 w-4" />
										مشاهدة مرة أخرى
									</Button>
								</CardFooter>
							</Card>
						))}
				</TabsContent>
			</Tabs>
		</div>
	);
}