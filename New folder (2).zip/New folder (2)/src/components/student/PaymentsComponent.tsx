import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CreditCard, Calendar } from "lucide-react";
import { useState } from "react";

// Mock data
const mockPayments = [
	{ id: 1, month: "July 2025", amount: 500, status: "Paid", date: "2025-07-02", method: "Credit Card" },
	{ id: 2, month: "June 2025", amount: 500, status: "Paid", date: "2025-06-01", method: "Cash" },
	{ id: 3, month: "May 2025", amount: 500, status: "Paid", date: "2025-05-03", method: "Vodafone Cash" },
	{ id: 4, month: "April 2025", amount: 500, status: "Paid", date: "2025-04-02", method: "Fawry" },
	{ id: 5, month: "August 2025", amount: 500, status: "Unpaid", dueDate: "2025-08-05" },
];

export default function PaymentsComponent() {
	const [paymentMethod, setPaymentMethod] = useState("none");
	const [showVodafone, setShowVodafone] = useState(false);

	// إضافة دوال تفعيل الأزرار
	const handlePayNow = (payment) => {
		if (payment.status === "Unpaid") {
			alert(`سيتم دفع رسوم شهر ${payment.month} (${payment.amount}$)`);
			// هنا يمكنك تنفيذ منطق الدفع الفعلي
		}
	};
	const handleReceipt = (payment) => {
		alert(`عرض إيصال دفع شهر ${payment.month}`);
		// هنا يمكنك فتح صفحة أو تحميل الإيصال
	};
	const handleAddPaymentMethod = () => {
		alert("إضافة طريقة دفع جديدة");
	};
	const handleDialogPay = () => {
		alert("تم الدفع بنجاح!");
	};
	const handleDialogCancel = () => {
		alert("تم إلغاء العملية");
	};

	return (
		<div
			className="space-y-6 font-[Cairo,Tajawal,sans-serif] min-h-screen px-2 md:px-8 py-6"
			dir="rtl"
			style={{
				background: "linear-gradient(120deg, #f1f5fe 0%, #e0e7ff 60%, #fbc2eb 100%)",
			}}
		>
			<div className="flex items-center justify-between mb-2">
				<h2 className="text-3xl font-extrabold tracking-tight flex items-center gap-2 text-indigo-800 drop-shadow">
					<CreditCard className="text-pink-500 bg-pink-100 rounded-full p-1" size={32} />
					المدفوعات
				</h2>
				<Dialog>
					<DialogTrigger asChild>
						<Button className="bg-gradient-to-r from-pink-400 to-purple-500 text-white font-bold shadow hover:brightness-110 btn-animate transition-transform duration-150 hover:scale-105">
							<CreditCard className="ml-2 h-4 w-4" />
							دفع الرسوم
						</Button>
					</DialogTrigger>
					<DialogContent className="sm:max-w-[425px] rounded-2xl shadow-2xl bg-gradient-to-br from-white via-indigo-50 to-pink-50 border border-indigo-100 animate-fade-in">
						<DialogHeader>
							<DialogTitle className="text-2xl font-extrabold text-indigo-800">إجراء دفع</DialogTitle>
							<DialogDescription className="text-purple-600 font-bold">
								اختر طريقة الدفع وأكمل دفع الرسوم الدراسية.
							</DialogDescription>
						</DialogHeader>
						<div className="py-4">
							<div className="mb-4">
								<Label className="font-bold text-indigo-700">الدفع عن</Label>
								<div className="rounded-xl border p-3 mt-1 bg-gradient-to-r from-pink-50 to-indigo-50 shadow">
									<div className="flex justify-between items-center">
										<div>
											<p className="font-bold text-pink-700">رسوم أغسطس 2025</p>
											<p className="text-sm text-gray-500 font-bold">مستحقة في 5 أغسطس 2025</p>
										</div>
										<p className="text-lg font-extrabold text-indigo-800">$500.00</p>
									</div>
								</div>
							</div>
							
							<div className="mb-4 space-y-2">
								<Label className="font-bold text-indigo-700">طريقة الدفع</Label>
								<RadioGroup
									defaultValue="none"
									value={paymentMethod}
									onValueChange={(value) => {
										setPaymentMethod(value);
										setShowVodafone(value === "vodafone-cash");
										if (value === "fawry") {
											window.open("https://www.fawry.com/payment-page", "_blank");
										}
									}}
								>
									<div className={`flex items-center space-x-2 rounded-xl border p-3 transition-all duration-200 ${paymentMethod === "vodafone-cash" ? "border-pink-400 bg-pink-50 shadow-lg" : "border-gray-200 bg-white"}`}>
										<RadioGroupItem value="vodafone-cash" id="vodafone-cash" />
										<Label htmlFor="vodafone-cash" className="flex-1 cursor-pointer font-bold text-pink-700">فودافون كاش</Label>
										<div className="h-6 w-14 rounded bg-red-100 flex items-center justify-center text-red-600 font-bold text-xs">ڤودافون</div>
									</div>
									<div className={`flex items-center space-x-2 rounded-xl border p-3 transition-all duration-200 ${paymentMethod === "fawry" ? "border-yellow-400 bg-yellow-50 shadow-lg" : "border-gray-200 bg-white"}`}>
										<RadioGroupItem value="fawry" id="fawry" />
										<Label htmlFor="fawry" className="flex-1 cursor-pointer font-bold text-yellow-700">فوري</Label>
										<div className="h-6 w-14 rounded bg-yellow-100 flex items-center justify-center text-yellow-700 font-bold text-xs">فوري</div>
									</div>
								</RadioGroup>
								{/* رقم فودافون كاش */}
								<div
									className={`mt-4 transition-all duration-300 overflow-hidden ${
										showVodafone ? "max-h-32 opacity-100" : "max-h-0 opacity-0"
									}`}
								>
									{showVodafone && (
										<div className="animate-fade-in">
											<Label className="mb-1 block font-bold text-pink-700">رقم فودافون كاش للتحويل</Label>
											<Input
												value="01023815204"
												readOnly
												className="bg-red-50 text-red-700 font-bold text-center cursor-default border-2 border-pink-300 rounded-xl text-lg tracking-widest shadow"
											/>
											<div className="text-xs text-gray-500 mt-2 text-center">انسخ الرقم وأرسل التحويل من تطبيق فودافون كاش</div>
										</div>
									)}
								</div>
							</div>
						</div>
						<DialogFooter>
							<Button variant="outline" className="font-bold" onClick={handleDialogCancel}>إلغاء</Button>
							<Button className="bg-gradient-to-r from-pink-400 to-purple-500 text-white font-bold shadow hover:brightness-110 btn-animate transition-transform duration-150 hover:scale-105" onClick={handleDialogPay}>
								ادفع $500.00
							</Button>
						</DialogFooter>
					</DialogContent>
				</Dialog>
			</div>
			
			<div className="grid gap-6 md:grid-cols-3">
				<Card className="bg-gradient-to-br from-white via-indigo-50 to-pink-50 rounded-2xl shadow-xl border border-indigo-100 animate-fade-in">
					<CardHeader className="pb-3">
						<CardTitle className="text-xl font-extrabold text-indigo-800">الرصيد الحالي</CardTitle>
						<CardDescription className="text-purple-600 font-bold">الرصيد المستحق عليك</CardDescription>
					</CardHeader>
					<CardContent>
						<div className="text-3xl font-extrabold text-pink-600 animate-bounce">{mockPayments.find(p => p.status === "Unpaid")?.amount ? `$${mockPayments.find(p => p.status === "Unpaid").amount}.00` : "$0.00"}</div>
						<p className="text-sm text-gray-500 mt-1 font-bold">
							عن شهر أغسطس 2025، مستحق في 5 أغسطس
						</p>
						<Button className="w-full mt-4 bg-gradient-to-r from-pink-400 to-purple-500 text-white font-bold shadow hover:brightness-110 btn-animate transition-transform duration-150 hover:scale-105">
							<CreditCard className="mr-2 h-4 w-4" />
							ادفع الآن
						</Button>
					</CardContent>
				</Card>
				
				<Card className="bg-gradient-to-br from-white via-pink-50 to-indigo-50 rounded-2xl shadow-xl border border-pink-100 animate-fade-in delay-100">
					<CardHeader className="pb-3">
						<CardTitle className="text-xl font-extrabold text-indigo-800">حالة المدفوعات</CardTitle>
						<CardDescription className="text-purple-600 font-bold">للعام الدراسي الحالي</CardDescription>
					</CardHeader>
					<CardContent>
						<div className="flex items-center justify-between mb-4">
							<div className="flex items-center gap-2">
								<div className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></div>
								<span className="text-sm font-bold text-green-700">مدفوع: 4</span>
							</div>
							<div className="flex items-center gap-2">
								<div className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></div>
								<span className="text-sm font-bold text-red-700">غير مدفوع: 1</span>
							</div>
						</div>
						<div className="space-y-2">
							{["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"].map((month, i) => (
								<div key={month} className="flex items-center gap-2">
									<div className="w-12 text-xs font-bold text-indigo-700">{month}</div>
									<div className="h-2 flex-1 bg-gray-100 rounded-full overflow-hidden">
										<div 
											className={`h-full transition-all duration-500 ${i <= 6 ? 'bg-green-500' : i === 7 ? 'bg-red-500' : 'bg-gray-300 animate-fade-in'}`} 
											style={{ width: i <= 7 ? '100%' : '0%' }}
										></div>
									</div>
								</div>
							))}
						</div>
					</CardContent>
				</Card>
				
				<Card className="bg-gradient-to-br from-white via-indigo-50 to-pink-50 rounded-2xl shadow-xl border border-indigo-100 animate-fade-in delay-200">
					<CardHeader className="pb-3">
						<CardTitle className="text-xl font-extrabold text-indigo-800">طرق الدفع</CardTitle>
						<CardDescription className="text-purple-600 font-bold">طرق الدفع المحفوظة لديك</CardDescription>
					</CardHeader>
					<CardContent>
						<div className="space-y-3">
							<div className="flex items-center p-3 border rounded-xl bg-gradient-to-r from-pink-50 to-indigo-50 shadow hover:scale-[1.02] transition-all duration-150">
								<div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center mr-3 shadow">
									<CreditCard className="h-5 w-5 text-indigo-500" />
								</div>
								<div>
									<p className="font-bold text-indigo-800">فيزا تنتهي بـ 4242</p>
									<p className="text-xs text-gray-500 font-bold">تنتهي في 12/25</p>
								</div>
								<Badge className="ml-auto bg-yellow-100 text-yellow-700 font-bold">افتراضي</Badge>
							</div>
							<Button variant="outline" className="w-full font-bold border-pink-400 text-pink-700 hover:bg-pink-50 btn-animate transition-transform duration-150 hover:scale-105"
								onClick={handleAddPaymentMethod}
							>
								إضافة طريقة دفع
							</Button>
						</div>
					</CardContent>
				</Card>
			</div>
			
			<Card className="bg-gradient-to-br from-white via-indigo-50 to-pink-50 rounded-2xl shadow-xl border border-indigo-100 animate-fade-in delay-300">
				<CardHeader>
					<CardTitle className="text-xl font-extrabold text-indigo-800">سجل المدفوعات</CardTitle>
					<CardDescription className="text-purple-600 font-bold">سجل مدفوعات الرسوم الدراسية</CardDescription>
				</CardHeader>
				<CardContent>
					<Tabs defaultValue="all" className="w-full">
						<TabsList className="grid w-full grid-cols-3 bg-gradient-to-r from-indigo-100 via-purple-100 to-pink-100 rounded-xl shadow mb-4">
							<TabsTrigger value="all" className="font-bold text-indigo-700">كل المدفوعات</TabsTrigger>
							<TabsTrigger value="paid" className="font-bold text-green-700">مدفوع</TabsTrigger>
							<TabsTrigger value="unpaid" className="font-bold text-red-700">غير مدفوع</TabsTrigger>
						</TabsList>
						
						<TabsContent value="all" className="mt-4">
							<Table>
								<TableHeader>
									<TableRow>
										<TableHead>الشهر</TableHead>
										<TableHead>المبلغ</TableHead>
										<TableHead>الحالة</TableHead>
										<TableHead>تاريخ الدفع</TableHead>
										<TableHead>الطريقة</TableHead>
										<TableHead className="text-right">إجراء</TableHead>
									</TableRow>
								</TableHeader>
								<TableBody>
									{mockPayments.map((payment) => (
										<TableRow key={payment.id}>
											<TableCell className="font-medium">{payment.month}</TableCell>
											<TableCell>${payment.amount}.00</TableCell>
											<TableCell>
												<Badge className={payment.status === 'Paid' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
													{payment.status}
												</Badge>
											</TableCell>
											<TableCell>{payment.date || '-'}</TableCell>
											<TableCell>{payment.method || '-'}</TableCell>
											<TableCell className="text-right">
												{payment.status === 'Paid' ? (
													<Button variant="ghost" size="sm" onClick={() => handleReceipt(payment)}>إيصال</Button>
												) : (
													<Button size="sm" className="bg-edu-pink hover:bg-edu-pink/90" onClick={() => handlePayNow(payment)}>ادفع الآن</Button>
												)}
											</TableCell>
										</TableRow>
									))}
								</TableBody>
							</Table>
						</TabsContent>
						
						<TabsContent value="paid" className="mt-4">
							<Table>
								<TableHeader>
									<TableRow>
										<TableHead>الشهر</TableHead>
										<TableHead>المبلغ</TableHead>
										<TableHead>الحالة</TableHead>
										<TableHead>تاريخ الدفع</TableHead>
										<TableHead>الطريقة</TableHead>
										<TableHead className="text-right">إجراء</TableHead>
									</TableRow>
								</TableHeader>
								<TableBody>
									{mockPayments.filter(p => p.status === 'Paid').map((payment) => (
										<TableRow key={payment.id}>
											<TableCell className="font-medium">{payment.month}</TableCell>
											<TableCell>${payment.amount}.00</TableCell>
											<TableCell>
												<Badge className="bg-green-100 text-green-800">
													{payment.status}
												</Badge>
											</TableCell>
											<TableCell>{payment.date}</TableCell>
											<TableCell>{payment.method}</TableCell>
											<TableCell className="text-right">
												<Button variant="ghost" size="sm" onClick={() => handleReceipt(payment)}>إيصال</Button>
											</TableCell>
										</TableRow>
									))}
								</TableBody>
							</Table>
						</TabsContent>
						
						<TabsContent value="unpaid" className="mt-4">
							<Table>
								<TableHeader>
									<TableRow>
										<TableHead>الشهر</TableHead>
										<TableHead>المبلغ</TableHead>
										<TableHead>الحالة</TableHead>
										<TableHead>تاريخ الاستحقاق</TableHead>
										<TableHead className="text-right">إجراء</TableHead>
									</TableRow>
								</TableHeader>
								<TableBody>
									{mockPayments.filter(p => p.status === 'Unpaid').map((payment) => (
										<TableRow key={payment.id}>
											<TableCell className="font-medium">{payment.month}</TableCell>
											<TableCell>${payment.amount}.00</TableCell>
											<TableCell>
												<Badge className="bg-red-100 text-red-800">
													{payment.status}
												</Badge>
											</TableCell>
											<TableCell>{payment.dueDate}</TableCell>
											<TableCell className="text-right">
												<Button size="sm" className="bg-edu-pink hover:bg-edu-pink/90" onClick={() => handlePayNow(payment)}>ادفع الآن</Button>
											</TableCell>
										</TableRow>
									))}
								</TableBody>
							</Table>
						</TabsContent>
					</Tabs>
				</CardContent>
			</Card>
		</div>
	);
}