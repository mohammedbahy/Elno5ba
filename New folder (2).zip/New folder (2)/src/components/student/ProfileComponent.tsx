import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { User, Mail, Calendar, Edit, Phone, MapPin, CalendarDays, School } from "lucide-react";

export default function ProfileComponent() {
  // بيانات تجريبية للطالب
  const student = {
    name: "محمد أحمد",
    email: "mohamed.ahmed@email.com",
    birthdate: "2005-03-15",
    grade: "الثالث الثانوي",
    avatar: "/images/Profile.jpg",
    status: "نشط",
    phone: "01012345678",
    address: "القاهرة، مصر",
    school: "مدرسة النيل الثانوية",
    guardian: "أحمد عبد الله",
    guardianPhone: "01098765432",
    registrationDate: "2022-09-01",
    nationalId: "30503151234567",
    gender: "ذكر",
  };

  return (
    <div
      className="min-h-[calc(100vh-32px)] px-2 md:px-8 py-6 font-[Cairo,Tajawal,sans-serif] flex items-center justify-center"
      dir="rtl"
      style={{
        background: "linear-gradient(120deg, #f1f5fe 0%, #e0e7ff 60%, #fbc2eb 100%)",
      }}
    >
      <div className="w-full max-w-4xl">
        <Card className="bg-gradient-to-br from-white via-indigo-50 to-pink-50 rounded-3xl shadow-2xl border border-indigo-100 animate-fade-in">
          <CardHeader className="flex flex-col items-center gap-2 pb-2">
            <Avatar className="w-32 h-32 mb-2 shadow-lg border-4 border-pink-200">
              <AvatarImage src={student.avatar} alt={student.name} />
              <AvatarFallback className="bg-gradient-to-tr from-pink-400 via-purple-400 to-indigo-400 text-white text-4xl">
                {student.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <CardTitle className="text-3xl font-extrabold text-indigo-800">{student.name}</CardTitle>
            <Badge className="bg-green-100 text-green-800 font-bold px-6 py-2 rounded-full text-lg">{student.status}</Badge>
            <CardDescription className="text-purple-600 font-bold mt-2 text-xl">{student.grade}</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
            <div className="flex items-center gap-3 bg-gradient-to-r from-pink-50 to-indigo-50 rounded-xl p-4 shadow">
              <Mail className="text-pink-500" />
              <span className="font-bold text-indigo-700 text-lg">{student.email}</span>
            </div>
            <div className="flex items-center gap-3 bg-gradient-to-r from-indigo-50 to-pink-50 rounded-xl p-4 shadow">
              <Phone className="text-purple-500" />
              <span className="font-bold text-indigo-700 text-lg">رقم الهاتف: {student.phone}</span>
            </div>
            <div className="flex items-center gap-3 bg-gradient-to-r from-pink-50 to-indigo-50 rounded-xl p-4 shadow">
              <CalendarDays className="text-indigo-500" />
              <span className="font-bold text-indigo-700 text-lg">تاريخ الميلاد: {student.birthdate}</span>
            </div>
            <div className="flex items-center gap-3 bg-gradient-to-r from-indigo-50 to-pink-50 rounded-xl p-4 shadow">
              <User className="text-pink-500" />
              <span className="font-bold text-indigo-700 text-lg">الصف الدراسي: {student.grade}</span>
            </div>
            <div className="flex items-center gap-3 bg-gradient-to-r from-pink-50 to-indigo-50 rounded-xl p-4 shadow">
              <School className="text-purple-500" />
              <span className="font-bold text-indigo-700 text-lg">المدرسة: {student.school}</span>
            </div>
            <div className="flex items-center gap-3 bg-gradient-to-r from-indigo-50 to-pink-50 rounded-xl p-4 shadow">
              <MapPin className="text-pink-500" />
              <span className="font-bold text-indigo-700 text-lg">العنوان: {student.address}</span>
            </div>
            <div className="flex items-center gap-3 bg-gradient-to-r from-pink-50 to-indigo-50 rounded-xl p-4 shadow">
              <User className="text-purple-500" />
              <span className="font-bold text-indigo-700 text-lg">ولي الأمر: {student.guardian}</span>
            </div>
            <div className="flex items-center gap-3 bg-gradient-to-r from-indigo-50 to-pink-50 rounded-xl p-4 shadow">
              <Phone className="text-pink-500" />
              <span className="font-bold text-indigo-700 text-lg">هاتف ولي الأمر: {student.guardianPhone}</span>
            </div>
            <div className="flex items-center gap-3 bg-gradient-to-r from-pink-50 to-indigo-50 rounded-xl p-4 shadow">
              <Calendar className="text-purple-500" />
              <span className="font-bold text-indigo-700 text-lg">تاريخ التسجيل: {student.registrationDate}</span>
            </div>
            <div className="flex items-center gap-3 bg-gradient-to-r from-indigo-50 to-pink-50 rounded-xl p-4 shadow">
              <User className="text-pink-500" />
              <span className="font-bold text-indigo-700 text-lg">الرقم القومي: {student.nationalId}</span>
            </div>
            <div className="flex items-center gap-3 bg-gradient-to-r from-pink-50 to-indigo-50 rounded-xl p-4 shadow">
              <User className="text-purple-500" />
              <span className="font-bold text-indigo-700 text-lg">النوع: {student.gender}</span>
            </div>
          </CardContent>
          <div className="flex justify-center p-6">
            <Button className="bg-gradient-to-r from-pink-400 to-purple-500 text-white font-bold shadow hover:brightness-110 btn-animate transition-transform duration-150 hover:scale-105 flex items-center gap-2 text-lg px-8 py-3 rounded-xl">
              <Edit className="h-5 w-5" />
              تعديل البيانات
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}