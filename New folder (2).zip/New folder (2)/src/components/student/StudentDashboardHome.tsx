import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Calendar, Check, Clock, FileText, Video, CreditCard, User, BarChart, CheckCircle } from "lucide-react";

import { useEffect, useState } from "react";

export default function StudentDashboardHome() {
  // بيانات افتراضية لكل صف
  const gradesData = {
    grade1: {
      attendance: 85.7,
      attended: 6,
      total: 7,
      lectures: 2,
      totalLectures: 5,
      avg: 88.5,
      exams: 2,
      payment: "مدفوع",
      paymentDate: "2 يوليو",
    },
    grade2: {
      attendance: 92.3,
      attended: 12,
      total: 13,
      lectures: 4,
      totalLectures: 6,
      avg: 91.2,
      exams: 3,
      payment: "مدفوع جزئياً",
      paymentDate: "5 يوليو",
    },
    grade3: {
      attendance: 78.4,
      attended: 8,
      total: 11,
      lectures: 3,
      totalLectures: 7,
      avg: 80.7,
      exams: 1,
      payment: "غير مدفوع",
      paymentDate: "-",
    },
  };
  const [selectedGrade, setSelectedGrade] = useState('grade1');
  useEffect(() => {
    const grade = localStorage.getItem('selectedGrade') || 'grade1';
    setSelectedGrade(grade);
  }, []);
  const data = gradesData[selectedGrade];
  return (
    <div className="space-y-6 font-[Cairo,Tajawal,sans-serif]" dir="rtl">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">لوحة التحكم</h2>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="bg-edu-yellow/20 text-edu-orange border-edu-yellow">
            <Calendar className="mr-1 h-3 w-3" />
            22 يوليو 2025
          </Badge>
        </div>
      </div>
      {/* بطاقات الإحصائيات */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1 bg-gradient-to-br from-white via-indigo-50 to-pink-50 rounded-2xl shadow-xl border border-indigo-100 hover:scale-[1.03] transition-transform duration-200">
          <div className="flex items-center gap-2 p-4">
            <CreditCard className="text-pink-500 bg-pink-100 rounded-full p-1" size={28} />
            <span className="text-lg font-bold text-indigo-700">حالة الدفع</span>
          </div>
          <div className="px-4 pb-4">
            <span className="text-2xl font-extrabold text-green-600">مدفوع</span>
            <div className="text-sm text-gray-500 mt-1">تم الدفع في 2 يوليو 2025</div>
            <div className="h-2 mt-3 rounded bg-green-100">
              <div className="h-2 rounded bg-green-400 w-full"></div>
            </div>
          </div>
        </div>
        <div className="flex-1 bg-gradient-to-br from-white via-purple-50 to-pink-50 rounded-2xl shadow-xl border border-purple-100 hover:scale-[1.03] transition-transform duration-200">
          <div className="flex items-center gap-2 p-4">
            <Video className="text-orange-500 bg-orange-100 rounded-full p-1" size={28} />
            <span className="text-lg font-bold text-purple-700">المحاضرات المكتملة</span>
          </div>
          <div className="px-4 pb-4">
            <span className="text-2xl font-extrabold text-orange-600">40%</span>
            <div className="text-sm text-gray-500 mt-1">أكملت 2 من أصل 5 محاضرات</div>
            <div className="h-2 mt-3 rounded bg-orange-100">
              <div className="h-2 rounded bg-orange-400 w-2/5"></div>
            </div>
          </div>
        </div>
        <div className="flex-1 bg-gradient-to-br from-white via-pink-50 to-indigo-50 rounded-2xl shadow-xl border border-pink-100 hover:scale-[1.03] transition-transform duration-200">
          <div className="flex items-center gap-2 p-4">
            <User className="text-purple-500 bg-purple-100 rounded-full p-1" size={28} />
            <span className="text-lg font-bold text-pink-700">نسبة الحضور</span>
          </div>
          <div className="px-4 pb-4">
            <span className="text-2xl font-extrabold text-purple-600">85.7%</span>
            <div className="text-sm text-gray-500 mt-1">حضرت 6 من أصل 7 حصص</div>
            <div className="h-2 mt-3 rounded bg-purple-100">
              <div className="h-2 rounded bg-purple-400 w-5/6"></div>
            </div>
          </div>
        </div>
      </div>
      {/* الأنشطة الحديثة */}
      <div className="bg-gradient-to-br from-white via-indigo-50 to-pink-50 rounded-2xl shadow-xl border border-indigo-100 p-6 mb-6">
        <h3 className="text-2xl font-extrabold text-indigo-800 flex items-center gap-2 mb-4">
          <BarChart className="text-pink-500" size={24} />
          الأنشطة الحديثة
        </h3>
        <ul className="space-y-4">
          <li className="flex items-center gap-3">
            <Video className="text-orange-500 bg-orange-100 rounded-full p-1" size={22} />
            <div>
              <span className="font-bold text-indigo-700">محاضرة جديدة متاحة</span>
              <div className="text-gray-500 text-sm">محاضرة أساسيات الفيزياء متاحة الآن للمشاهدة</div>
              <div className="text-xs text-orange-500 mt-1">منذ 5 ساعات</div>
            </div>
          </li>
          <li className="flex items-center gap-3">
            <CheckCircle className="text-green-500 bg-green-100 rounded-full p-1" size={22} />
            <div>
              <span className="font-bold text-green-700">تم تسجيل الحضور</span>
              <div className="text-gray-500 text-sm">تم تسجيل حضورك في حصة الرياضيات</div>
              <div className="text-xs text-green-500 mt-1">منذ يوم</div>
            </div>
          </li>
          <li className="flex items-center gap-3">
            <FileText className="text-pink-500 bg-pink-100 rounded-full p-1" size={22} />
            <div>
              <span className="font-bold text-pink-700">اختبار قادم</span>
              <div className="text-gray-500 text-sm">اختبار منتصف الفصل المقرر في 25 يوليو 2025</div>
              <div className="text-xs text-pink-500 mt-1">منذ يومين</div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  );
}