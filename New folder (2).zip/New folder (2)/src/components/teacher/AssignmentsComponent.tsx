import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon, FileText, Filter, Plus, Search, Upload } from "lucide-react";
import { useState } from "react";

// Mock data
const mockAssignments = [
  { 
    id: 1, 
    title: "Newton's Laws of Motion", 
    class: "Physics Fundamentals", 
    type: "Homework",
    dueDate: new Date(2025, 6, 28), // July 28, 2025
    status: "active", 
    submitted: 18, 
    total: 24
  },
  { 
    id: 2, 
    title: "Quadratic Equations Problem Set", 
    class: "Advanced Mathematics", 
    type: "Quiz",
    dueDate: new Date(2025, 6, 25), // July 25, 2025
    status: "active", 
    submitted: 15, 
    total: 22
  },
  { 
    id: 3, 
    title: "Cell Structure Analysis", 
    class: "Biology Lab", 
    type: "Lab Report",
    dueDate: new Date(2025, 6, 30), // July 30, 2025
    status: "active", 
    submitted: 10, 
    total: 18
  },
  { 
    id: 4, 
    title: "Chemical Reactions Exam", 
    class: "Chemistry", 
    type: "Exam",
    dueDate: new Date(2025, 6, 24), // July 24, 2025
    status: "active", 
    submitted: 20, 
    total: 20
  },
  { 
    id: 5, 
    title: "Physics Mid-Term Paper", 
    class: "Physics Fundamentals", 
    type: "Paper",
    dueDate: new Date(2025, 6, 15), // July 15, 2025
    status: "graded", 
    submitted: 24, 
    total: 24,
    avgScore: 86
  },
  { 
    id: 6, 
    title: "Calculus Fundamentals", 
    class: "Advanced Mathematics", 
    type: "Homework",
    dueDate: new Date(2025, 6, 10), // July 10, 2025
    status: "graded", 
    submitted: 22, 
    total: 22,
    avgScore: 78
  },
  { 
    id: 7, 
    title: "DNA Extraction Lab", 
    class: "Biology Lab", 
    type: "Lab Report",
    dueDate: new Date(2025, 6, 5), // July 5, 2025
    status: "graded", 
    submitted: 16, 
    total: 18,
    avgScore: 92
  },
];

export default function AssignmentsComponent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  
  const activeAssignments = mockAssignments.filter(a => a.status === "active" && 
    (searchTerm ? a.title.toLowerCase().includes(searchTerm.toLowerCase()) || a.class.toLowerCase().includes(searchTerm.toLowerCase()) : true));
  
  const gradedAssignments = mockAssignments.filter(a => a.status === "graded" &&
    (searchTerm ? a.title.toLowerCase().includes(searchTerm.toLowerCase()) || a.class.toLowerCase().includes(searchTerm.toLowerCase()) : true));
  
  return (
    <div className="space-y-6 font-[Cairo,Tajawal,sans-serif]" dir="rtl">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">الامتحانات</h2>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-edu-orange hover:bg-edu-orange/90">
              <Plus className="ml-2 h-4 w-4" />
              إنشاء امتحان
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>إنشاء امتحان جديد</DialogTitle>
              <DialogDescription>
                أدخل تفاصيل الامتحان .
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="assignment-title">عنوان الامتحان</label>
                <Input id="assignment-title" placeholder="أدخل عنوان الامتحان" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="assignment-class">الصف</label>
                  <Select>
                    <SelectTrigger id="assignment-class">
                    <SelectValue placeholder="اختر الصف" />
                    </SelectTrigger>
                    <SelectContent>
                    <SelectItem value="physics">الصف الاول الثانوي</SelectItem>
                    <SelectItem value="mathematics">الصف الثاني الثانوي </SelectItem>
                    <SelectItem value="biology"> الصف الثالث الثانوي</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <label htmlFor="assignment-type">نوع الامتحان</label>
                  <Select>
                    <SelectTrigger id="assignment-type">
                    <SelectValue placeholder="اختر النوع" />
                    </SelectTrigger>
                    <SelectContent>
                    <SelectItem value="quiz">اختبار قصير</SelectItem>
                    <SelectItem value="exam">امتحان</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label>تاريخ التسليم</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {selectedDate ? format(selectedDate, "PPP") : "اختر التاريخ"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={selectedDate}
                        onSelect={setSelectedDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div className="grid gap-2">
                  <label htmlFor="assignment-points">الدرجة الكلية</label>
                  <Input id="assignment-points" type="number" placeholder="أدخل الدرجة" />
                </div>
              </div>
              <div className="grid gap-2">
                <label htmlFor="assignment-description">وصف الامتحان</label>
                <Textarea 
                  id="assignment-description" 
                  placeholder="صِف الامتحان والمتطلبات والتعليمات..."
                  rows={5}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Button variant="outline" className="flex-1">
                  <Upload className="mr-2 h-4 w-4" />
                  رفع ملفات
                </Button>
                <Button variant="outline" className="flex-1">
                  <FileText className="mr-2 h-4 w-4" />
                  إرفاق مصادر
                </Button>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline">حفظ كمسودة</Button>
              <Button className="bg-edu-orange hover:bg-edu-orange/90">إنشاء ونشر</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Search and filter */}
      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="ابحث عن الامتحان..." 
            className="pl-8" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button variant="outline" className="gap-1">
          <Filter className="h-4 w-4" />
          تصفية
        </Button>
        <Select defaultValue="all">
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="الصف" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الصفوف</SelectItem>
            <SelectItem value="grade1">الصف الأول</SelectItem>
            <SelectItem value="grade2">الصف الثاني</SelectItem>
            <SelectItem value="grade3">الصف الثالث</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {/* Assignments Tabs */}
      <Tabs defaultValue="active" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="active">الامتحانات النشطة</TabsTrigger>
          <TabsTrigger value="graded">الامتحانات المصححة</TabsTrigger>
        </TabsList>
        
        <TabsContent value="active" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>الامتحانات النشطة</CardTitle>
              <CardDescription>الامتحانات المفتوحة حالياً للتسليم</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[300px]">الامتحان</TableHead>
                    <TableHead>الصف</TableHead>
                    <TableHead>النوع</TableHead>
                    <TableHead>تاريخ التسليم</TableHead>
                    <TableHead>التسليمات</TableHead>
                    <TableHead className="text-right">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activeAssignments.map((assignment) => (
                    <TableRow key={assignment.id}>
                      <TableCell className="font-medium">{assignment.title}</TableCell>
                      <TableCell>
                        <Badge className={
                          assignment.class === 'Advanced Mathematics' 
                            ? 'bg-edu-orange text-white' 
                            : assignment.class === 'Biology Lab' 
                              ? 'bg-green-500 text-white' 
                              : assignment.class === 'Chemistry'
                                ? 'bg-edu-yellow text-foreground'
                                : 'bg-edu-yellow text-foreground'
                        }>
                          {assignment.class}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{assignment.type}</Badge>
                      </TableCell>
                      <TableCell>{format(assignment.dueDate, "MMM d, yyyy")}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="h-2 rounded-full bg-edu-purple" 
                              style={{ width: `${(assignment.submitted / assignment.total) * 100}%` }}
                            ></div>
                          </div>
                          <span className="text-xs whitespace-nowrap">{assignment.submitted}/{assignment.total}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button size="sm" variant="outline" className="mr-2">عرض</Button>
                        <Button size="sm" className="bg-edu-pink hover:bg-edu-pink/90">تصحيح</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="graded" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>الامتحانات المصححة</CardTitle>
              <CardDescription>الامتحانات التي تم تصحيحها</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[300px]">الامتحان</TableHead>
                    <TableHead>الصف</TableHead>
                    <TableHead>النوع</TableHead>
                    <TableHead>تاريخ التسليم</TableHead>
                    <TableHead>متوسط الدرجة</TableHead>
                    <TableHead className="text-right">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {gradedAssignments.map((assignment) => (
                    <TableRow key={assignment.id}>
                      <TableCell className="font-medium">{assignment.title}</TableCell>
                      <TableCell>
                        <Badge className={
                          assignment.class === 'Advanced Mathematics' 
                            ? 'bg-edu-orange text-white' 
                            : assignment.class === 'Biology Lab' 
                              ? 'bg-green-500 text-white' 
                              : assignment.class === 'Chemistry'
                                ? 'bg-edu-yellow text-foreground'
                                : 'bg-edu-yellow text-foreground'
                        }>
                          {assignment.class}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{assignment.type}</Badge>
                      </TableCell>
                      <TableCell>{format(assignment.dueDate, "MMM d, yyyy")}</TableCell>
                      <TableCell>
                        <span className={
                          (assignment.avgScore || 0) >= 90 
                            ? "text-green-600 font-medium" 
                            : (assignment.avgScore || 0) >= 80 
                              ? "text-edu-orange font-medium" 
                              : "text-red-500 font-medium"
                        }>
                          {assignment.avgScore}%
                        </span>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button size="sm" variant="outline" className="mr-2">عرض</Button>
                        <Button size="sm" className="bg-edu-orange hover:bg-edu-orange/90">تحليل</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}