import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { CalendarIcon, Clock, Download, Filter, Search, Users } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";

// Mock data
const mockClasses = [
  { id: 1, name: "الصف الأول الثانوي", students: 24, schedule: "10:00 ص", room: "101" },
  { id: 2, name: "الصف الثاني الثانوي", students: 22, schedule: "12:00 م", room: "204" },
  { id: 3, name: "الصف الثالث الثانوي", students: 18, schedule: "2:00 م", room: "Lab 3" },
];

const mockStudents = [
  { id: 1, name: "Alex Johnson", status: "present", date: new Date(2025, 6, 22), class: "الصف الأول الثانوي" },
  { id: 2, name: "Sarah Williams", status: "absent", date: new Date(2025, 6, 22), class: "الصف الأول الثانوي" },
  { id: 3, name: "Michael Brown", status: "present", date: new Date(2025, 6, 22), class: "الصف الأول الثانوي" },
  { id: 4, name: "Emma Davis", status: "present", date: new Date(2025, 6, 22), class: "الصف الأول الثانوي" },
  { id: 5, name: "James Wilson", status: "late", date: new Date(2025, 6, 22), class: "الصف الأول الثانوي" },
  { id: 6, name: "Olivia Martin", status: "present", date: new Date(2025, 6, 22), class: "الصف الثاني الثانوي" },
  { id: 7, name: "William Garcia", status: "absent", date: new Date(2025, 6, 22), class: "الصف الثاني الثانوي" },
  { id: 8, name: "Sophia Rodriguez", status: "present", date: new Date(2025, 6, 22), class: "الصف الثاني الثانوي" },
  { id: 9, name: "Benjamin Lee", status: "present", date: new Date(2025, 6, 22), class: "الصف الثاني الثانوي" },
  { id: 10, name: "Isabella Lopez", status: "excused", date: new Date(2025, 6, 22), class: "الصف الثاني الثانوي" },
];

// Stats data
const attendanceStats = {
  present: { count: 72, percentage: 72 },
  absent: { count: 15, percentage: 15 },
  late: { count: 8, percentage: 8 },
  excused: { count: 5, percentage: 5 },
};

export default function AttendanceManagementComponent() {
  const [searchTerm, setSearchTerm] = useState("");
  // اجعل القيمة الافتراضية هي الصف الأول الثانوي
  const [selectedClass, setSelectedClass] = useState<string>(mockClasses[0].name);
  const [date, setDate] = useState<Date>(new Date());
  const [students, setStudents] = useState(mockStudents);
  
  const filteredStudents = students.filter(student => 
    student.class === selectedClass && 
    (searchTerm === "" || student.name.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  
  const updateAttendanceStatus = (studentId: number, status: string) => {
    setStudents(prev => prev.map(student => 
      student.id === studentId ? { ...student, status } : student
    ));
  };
  
  return (
    <div className="space-y-6 font-[Cairo,Tajawal,sans-serif]" dir="rtl">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">إدارة الحضور</h2>
        <div className="flex space-x-2">
          <Button variant="outline" className="gap-1">
            <Download className="h-4 w-4" />
            تصدير
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button className="bg-edu-orange hover:bg-edu-orange/90 gap-1">
                <Clock className="h-4 w-4" />
                تسجيل الحضور
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
              <DialogTitle>تسجيل حضور الصف</DialogTitle>
              <DialogDescription>
                اختر الصف والتاريخ لتسجيل الحضور.
              </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <label htmlFor="attendance-class">اختر الصف</label>
                  <Select defaultValue={selectedClass}>
                    <SelectTrigger id="attendance-class">
                      <SelectValue placeholder="اختر الصف" />
                    </SelectTrigger>
                    <SelectContent>
                      {mockClasses.map(cls => (
                        <SelectItem key={cls.id} value={cls.name}>{cls.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <label>اختر التاريخ</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant={"outline"}
                        className="w-full justify-start text-left font-normal"
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, 'PPP') : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={setDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline">إلغاء</Button>
                <Button className="bg-edu-orange hover:bg-edu-orange/90">بدء التسجيل</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle>حضور اليوم</CardTitle>
              <CardDescription className="flex items-center mt-1">
                <CalendarIcon className="mr-1 h-4 w-4" />
                {format(new Date(), "EEEE, MMMM d, yyyy")}
              </CardDescription>
            </div>
            <div className="flex flex-col md:flex-row gap-3">
              <Select 
                defaultValue={selectedClass}
                onValueChange={setSelectedClass}
              >
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="اختر الصف" />
                </SelectTrigger>
                <SelectContent>
                  {mockClasses.map(cls => (
                    <SelectItem key={cls.id} value={cls.name}>{cls.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="ابحث عن الطلاب..." 
                  className="pl-8" 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[250px]">اسم الطالب</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead className="text-right">إجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStudents.map((student) => (
                <TableRow key={student.id}>
                  <TableCell className="font-medium">{student.name}</TableCell>
                  <TableCell>
                    <Badge className={
                      student.status === 'present' 
                        ? 'bg-green-500 text-white' 
                        : student.status === 'absent' 
                          ? 'bg-red-500 text-white' 
                          : student.status === 'late' 
                            ? 'bg-edu-orange text-white' 
                            : 'bg-edu-purple text-white'
                    }>
                      {student.status === 'present' ? 'حاضر' : student.status === 'absent' ? 'غائب' : student.status === 'late' ? 'متأخر' : 'مُعذَر'}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Select 
                      defaultValue={student.status}
                      onValueChange={(value) => updateAttendanceStatus(student.id, value)}
                    >
                      <SelectTrigger className="w-[130px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="present">حاضر</SelectItem>
                        <SelectItem value="absent">غائب</SelectItem>
                        <SelectItem value="late">متأخر</SelectItem>
                        <SelectItem value="excused">مُعذَر</SelectItem>
                      </SelectContent>
                    </Select>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      {/* Statistics */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>إحصائيات الحضور</CardTitle>
            <CardDescription>إجمالي الحضور للفصل الحالي</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-3">
                <div className="flex flex-col items-center justify-center p-4 border rounded-lg">
                  <div className="text-3xl font-bold text-green-600">{attendanceStats.present.percentage}%</div>
                  <div className="text-sm text-muted-foreground">حاضر</div>
                </div>
                <div className="flex flex-col items-center justify-center p-4 border rounded-lg">
                  <div className="text-3xl font-bold text-red-500">{attendanceStats.absent.percentage}%</div>
                  <div className="text-sm text-muted-foreground">غائب</div>
                </div>
                <div className="flex flex-col items-center justify-center p-4 border rounded-lg">
                  <div className="text-3xl font-bold text-edu-orange">{attendanceStats.late.percentage}%</div>
                  <div className="text-sm text-muted-foreground">متأخر</div>
                </div>
                <div className="flex flex-col items-center justify-center p-4 border rounded-lg">
                  <div className="text-3xl font-bold text-edu-purple">{attendanceStats.excused.percentage}%</div>
                  <div className="text-sm text-muted-foreground">مُعذَر</div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="text-sm font-medium">نظرة عامة على الحضور</div>
                <div className="h-3 w-full rounded-full overflow-hidden bg-gray-100 flex">
                  <div className="h-full bg-green-500" style={{ width: `${attendanceStats.present.percentage}%` }}></div>
                  <div className="h-full bg-edu-orange" style={{ width: `${attendanceStats.late.percentage}%` }}></div>
                  <div className="h-full bg-edu-purple" style={{ width: `${attendanceStats.excused.percentage}%` }}></div>
                  <div className="h-full bg-red-500" style={{ width: `${attendanceStats.absent.percentage}%` }}></div>
                </div>
                <div className="flex text-xs justify-between">
                  <div>{attendanceStats.present.count} حاضر</div>
                  <div>{attendanceStats.late.count} متأخر</div>
                  <div>{attendanceStats.excused.count} مُعذَر</div>
                  <div>{attendanceStats.absent.count} غائب</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>نسب حضور الصفوف</CardTitle>
            <CardDescription>نسبة الحضور لكل صف</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-5">
              {mockClasses.map((cls) => (
                <div key={cls.id} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <div className={`w-3 h-3 rounded-full mr-2 ${
                        cls.id === 1 ? 'bg-edu-yellow' :
                        cls.id === 2 ? 'bg-edu-orange' :
                        cls.id === 3 ? 'bg-green-500' :
                        'bg-edu-pink'
                      }`}></div>
                      <div className="space-y-0.5">
                        <div className="font-medium text-sm">{cls.name}</div>
                        <div className="text-xs text-muted-foreground flex items-center">
                          <Users className="mr-1 h-3 w-3" />
                          {cls.students} طالب • القاعة {cls.room}
                        </div>
                      </div>
                    </div>
                    <div className="font-medium">
                      {cls.id === 1 ? '88%' :
                       cls.id === 2 ? '92%' :
                       cls.id === 3 ? '94%' :
                       '85%'}
                    </div>
                  </div>
                  <div className="h-2 w-full bg-gray-100 rounded-full">
                    <div className={`h-full rounded-full ${
                      cls.id === 1 ? 'bg-edu-yellow' :
                      cls.id === 2 ? 'bg-edu-orange' :
                      cls.id === 3 ? 'bg-green-500' :
                      'bg-edu-pink'
                    }`} style={{ 
                      width: cls.id === 1 ? '88%' :
                             cls.id === 2 ? '92%' :
                             cls.id === 3 ? '94%' :
                             '85%' 
                    }}></div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Attendance History */}
      <Card>
        <CardHeader>
          <CardTitle>سجل الحضور</CardTitle>
          <CardDescription>سجلات الحضور الأخيرة</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="records" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="records">سجلات الحضور</TabsTrigger>
            <TabsTrigger value="reports">التقارير</TabsTrigger>
            </TabsList>
            <TabsContent value="records" className="mt-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" className="gap-1">
                    <Filter className="h-3.5 w-3.5" />
                    تصفية
                  </Button>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" size="sm" className="gap-1">
                        <CalendarIcon className="h-3.5 w-3.5" />
                        {format(new Date(), "MMM yyyy")}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={new Date()}
                        onSelect={() => {}}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-3.5 w-3.5" />
                  تصدير CSV
                </Button>
              </div>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>الصف</TableHead>
                    <TableHead>حاضر</TableHead>
                    <TableHead>غائب</TableHead>
                    <TableHead>متأخر</TableHead>
                    <TableHead>مُعذَر</TableHead>
                    <TableHead className="text-right">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell>{format(new Date(2025, 6, 22), "MMM d, yyyy")}</TableCell>
                    <TableCell>Physics Fundamentals</TableCell>
                    <TableCell className="text-green-600">20</TableCell>
                    <TableCell className="text-red-500">2</TableCell>
                    <TableCell className="text-edu-orange">1</TableCell>
                    <TableCell className="text-edu-purple">1</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm">عرض</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{format(new Date(2025, 6, 22), "MMM d, yyyy")}</TableCell>
                    <TableCell>Advanced Mathematics</TableCell>
                    <TableCell className="text-green-600">19</TableCell>
                    <TableCell className="text-red-500">1</TableCell>
                    <TableCell className="text-edu-orange">0</TableCell>
                    <TableCell className="text-edu-purple">2</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm">View</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{format(new Date(2025, 6, 21), "MMM d, yyyy")}</TableCell>
                    <TableCell>Biology Lab</TableCell>
                    <TableCell className="text-green-600">17</TableCell>
                    <TableCell className="text-red-500">1</TableCell>
                    <TableCell className="text-edu-orange">0</TableCell>
                    <TableCell className="text-edu-purple">0</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm">View</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{format(new Date(2025, 6, 21), "MMM d, yyyy")}</TableCell>
                    <TableCell>Chemistry</TableCell>
                    <TableCell className="text-green-600">18</TableCell>
                    <TableCell className="text-red-500">1</TableCell>
                    <TableCell className="text-edu-orange">1</TableCell>
                    <TableCell className="text-edu-purple">0</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm">View</Button>
                    </TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell>{format(new Date(2025, 6, 20), "MMM d, yyyy")}</TableCell>
                    <TableCell>Physics Fundamentals</TableCell>
                    <TableCell className="text-green-600">21</TableCell>
                    <TableCell className="text-red-500">2</TableCell>
                    <TableCell className="text-edu-orange">1</TableCell>
                    <TableCell className="text-edu-purple">0</TableCell>
                    <TableCell className="text-right">
                      <Button variant="outline" size="sm">View</Button>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </TabsContent>
            <TabsContent value="reports" className="mt-4">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium">التقارير المتاحة</h3>
                <Button className="bg-edu-pink hover:bg-edu-pink/90">إنشاء تقرير</Button>
              </div>
              <div className="space-y-4">
                <Card className="border-dashed">
                  <CardContent className="p-4 flex justify-between items-center">
                    <div className="space-y-1">
                      <div className="font-medium">ملخص الحضور الشهري</div>
                      <div className="text-sm text-muted-foreground">يوليو 2025</div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      تحميل
                    </Button>
                  </CardContent>
                </Card>
                <Card className="border-dashed">
                  <CardContent className="p-4 flex justify-between items-center">
                    <div className="space-y-1">
                      <div className="font-medium">تقرير حضور الطلاب</div>
                      <div className="text-sm text-muted-foreground">جميع الصفوف - الفصل الحالي</div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                  </CardContent>
                </Card>
                <Card className="border-dashed">
                  <CardContent className="p-4 flex justify-between items-center">
                    <div className="space-y-1">
                      <div className="font-medium">تقرير مقارنة الصفوف</div>
                      <div className="text-sm text-muted-foreground">معدلات الحضور عبر جميع الصفوف</div>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="mr-2 h-4 w-4" />
                      Download
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}