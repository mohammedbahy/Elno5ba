import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, Calendar, Clock, Plus, Search, Users } from "lucide-react";
import { useState } from "react";

// Mock data
const mockClasses = [
  { id: 1, name: "Physics Fundamentals", subject: "Science", room: "101", schedule: "Mon, Wed, Fri 10:00 AM", students: 24 },
  { id: 2, name: "Advanced Mathematics", subject: "Mathematics", room: "204", schedule: "Mon, Wed, Fri 12:00 PM", students: 22 },
  { id: 3, name: "Biology Lab", subject: "Science", room: "Lab 3", schedule: "Mon, Wed, Fri 2:00 PM", students: 18 },
  { id: 4, name: "Chemistry", subject: "Science", room: "Lab 2", schedule: "Tue, Thu 11:00 AM", students: 20 },
];

// بيانات الحصص حسب الصفوف
const gradeClasses = {
  "الصف الأول الثانوي": [
    { id: 1, name: "الرياضيات", subject: "رياضيات", room: "101", schedule: "10:00 ص", students: 24 },
    { id: 2, name: "العلوم", subject: "علوم", room: "102", schedule: "12:00 م", students: 24 },
  ],
  "الصف الثاني الثانوي": [
    { id: 3, name: "اللغة العربية", subject: "عربي", room: "201", schedule: "9:00 ص", students: 22 },
    { id: 4, name: "الفيزياء", subject: "فيزياء", room: "202", schedule: "11:00 ص", students: 22 },
  ],
  "الصف الثالث الثانوي": [
    { id: 5, name: "الإنجليزي", subject: "إنجليزي", room: "301", schedule: "8:00 ص", students: 18 },
    { id: 6, name: "الكيمياء", subject: "كيمياء", room: "302", schedule: "10:00 ص", students: 18 },
  ],
};

export default function ClassesComponent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedGrade, setSelectedGrade] = useState("الصف الأول الثانوي");

  // تصفية الحصص حسب الصف والبحث
  const filteredClasses = gradeClasses[selectedGrade].filter(c =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.subject.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 font-[Cairo,Tajawal,sans-serif]" dir="rtl">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">الحصص</h2>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-edu-pink hover:bg-edu-pink/90">
              <Plus className="ml-2 h-4 w-4" />
              إنشاء فصل جديد
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>إنشاء فصل جديد</DialogTitle>
              <DialogDescription>
                أدخل تفاصيل الفصل الجديد.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="class-name">اسم الفصل</label>
                <Input id="class-name" placeholder="أدخل اسم الفصل" />
              </div>
              <div className="grid gap-2">
                <label htmlFor="subject">المادة</label>
                <Select>
                  <SelectTrigger id="subject">
                    <SelectValue placeholder="اختر المادة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mathematics">الرياضيات</SelectItem>
                    <SelectItem value="science">العلوم</SelectItem>
                    <SelectItem value="history">التاريخ</SelectItem>
                    <SelectItem value="english">الإنجليزية</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="room">القاعة</label>
                  <Input id="room" placeholder="رقم القاعة" />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="capacity">السعة</label>
                  <Input id="capacity" type="number" placeholder="عدد الطلاب الأقصى" />
                </div>
              </div>
              <div className="grid gap-2">
                <label htmlFor="schedule">الجدول</label>
                <Input id="schedule" placeholder="مثال: الاثنين، الأربعاء، الجمعة 10:00 ص" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline">إلغاء</Button>
              <Button className="bg-edu-pink hover:bg-edu-pink/90">إنشاء الفصل</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Search and filter */}
      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="ابحث عن الحصص..." 
            className="pl-8" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select defaultValue={selectedGrade} onValueChange={setSelectedGrade}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="اختر الصف" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="الصف الأول الثانوي">الصف الأول الثانوي</SelectItem>
            <SelectItem value="الصف الثاني الثانوي">الصف الثاني الثانوي</SelectItem>
            <SelectItem value="الصف الثالث الثانوي">الصف الثالث الثانوي</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {/* Classes Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {filteredClasses.map((cls) => (
          <Card key={cls.id} className="overflow-hidden">
            <div className="h-2 bg-edu-orange"></div>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle>{cls.name}</CardTitle>
                <Badge className="bg-edu-yellow text-foreground">{cls.subject}</Badge>
              </div>
              <CardDescription className="flex items-center gap-1">
                <Clock className="h-3 و-3" /> {cls.schedule}
              </CardDescription>
            </CardHeader>
            <CardContent className="pb-3">
              <div className="flex items-center justify-between text-sm mb-3">
                <div className="flex items-center gap-1">
                  <BookOpen className="h-4 w-4 text-muted-foreground" /> 
                  <span>القاعة {cls.room}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4 text-muted-foreground" /> 
                  <span>{cls.students} طالب</span>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button className="flex-1" variant="outline">
                  <Users className="mr-2 h-4 w-4" />
                  الطلاب
                </Button>
                <Button className="flex-1 bg-edu-pink hover:bg-edu-pink/90">
                  إدارة
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {/* Class Schedule */}
      <Card>
        <CardHeader>
          <CardTitle>جدول الحصص</CardTitle>
          <CardDescription>جدول الحصص الأسبوعي</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="weekly" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="weekly">عرض أسبوعي</TabsTrigger>
              <TabsTrigger value="list">عرض قائمة</TabsTrigger>
            </TabsList>
            
            <TabsContent value="weekly" className="mt-4">
              <div className="rounded-lg border">
                <div className="grid grid-cols-6 gap-px bg-muted">
                  <div className="bg-card p-3"></div>
                  <div className="bg-card p-3 text-center text-xs font-medium">الاثنين</div>
                  <div className="bg-card p-3 text-center text-xs font-medium">الثلاثاء</div>
                  <div className="bg-card p-3 text-center text-xs font-medium">الأربعاء</div>
                  <div className="bg-card p-3 text-center text-xs font-medium">الخميس</div>
                  <div className="bg-card p-3 text-center text-xs font-medium">الجمعة</div>
                </div>
                
                {/* 10:00 AM Row */}
                <div className="grid grid-cols-6 gap-px bg-muted">
                  <div className="bg-card p-3 text-center text-xs font-medium">10:00 ص</div>
                  <div className="bg-card p-3">
                    <div className="rounded-md bg-edu-yellow/20 p-2 text-xs border-l-2 border-edu-yellow">
                    <p className="font-medium">أساسيات الفيزياء</p>
                    <p className="text-muted-foreground mt-1">القاعة 101</p>
                    </div>
                  </div>
                  <div className="bg-card p-3"></div>
                  <div className="bg-card p-3">
                    <div className="rounded-md bg-edu-yellow/20 p-2 text-xs border-l-2 border-edu-yellow">
                      <p className="font-medium">Physics Fundamentals</p>
                      <p className="text-muted-foreground mt-1">Room 101</p>
                    </div>
                  </div>
                  <div className="bg-card p-3"></div>
                  <div className="bg-card p-3">
                    <div className="rounded-md bg-edu-yellow/20 p-2 text-xs border-l-2 border-edu-yellow">
                      <p className="font-medium">Physics Fundamentals</p>
                      <p className="text-muted-foreground mt-1">Room 101</p>
                    </div>
                  </div>
                </div>
                
                {/* 11:00 AM Row */}
                <div className="grid grid-cols-6 gap-px bg-muted">
                  <div className="bg-card p-3 text-center text-xs font-medium">11:00 ص</div>
                  <div className="bg-card p-3"></div>
                  <div className="bg-card p-3">
                    <div className="rounded-md bg-edu-yellow/20 p-2 text-xs border-l-2 border-edu-yellow">
                    <p className="font-medium">الكيمياء</p>
                    <p className="text-muted-foreground mt-1">المعمل 2</p>
                    </div>
                  </div>
                  <div className="bg-card p-3"></div>
                  <div className="bg-card p-3">
                    <div className="rounded-md bg-edu-yellow/20 p-2 text-xs border-l-2 border-edu-yellow">
                      <p className="font-medium">Chemistry</p>
                      <p className="text-muted-foreground mt-1">Lab 2</p>
                    </div>
                  </div>
                  <div className="bg-card p-3"></div>
                </div>
                
                {/* 12:00 PM Row */}
                <div className="grid grid-cols-6 gap-px bg-muted">
                  <div className="bg-card p-3 text-center text-xs font-medium">12:00 م</div>
                  <div className="bg-card p-3">
                    <div className="rounded-md bg-edu-orange/20 p-2 text-xs border-l-2 border-edu-orange">
                    <p className="font-medium">الرياضيات المتقدمة</p>
                    <p className="text-muted-foreground mt-1">القاعة 204</p>
                    </div>
                  </div>
                  <div className="bg-card p-3"></div>
                  <div className="bg-card p-3">
                    <div className="rounded-md bg-edu-orange/20 p-2 text-xs border-l-2 border-edu-orange">
                      <p className="font-medium">Advanced Mathematics</p>
                      <p className="text-muted-foreground mt-1">Room 204</p>
                    </div>
                  </div>
                  <div className="bg-card p-3"></div>
                  <div className="bg-card p-3">
                    <div className="rounded-md bg-edu-orange/20 p-2 text-xs border-l-2 border-edu-orange">
                      <p className="font-medium">Advanced Mathematics</p>
                      <p className="text-muted-foreground mt-1">Room 204</p>
                    </div>
                  </div>
                </div>
                
                {/* 2:00 PM Row */}
                <div className="grid grid-cols-6 gap-px bg-muted">
                  <div className="bg-card p-3 text-center text-xs font-medium">2:00 م</div>
                  <div className="bg-card p-3">
                    <div className="rounded-md bg-green-100 p-2 text-xs border-l-2 border-green-500">
                    <p className="font-medium">مختبر الأحياء</p>
                    <p className="text-muted-foreground mt-1">المعمل 3</p>
                    </div>
                  </div>
                  <div className="bg-card p-3"></div>
                  <div className="bg-card p-3">
                    <div className="rounded-md bg-green-100 p-2 text-xs border-l-2 border-green-500">
                      <p className="font-medium">Biology Lab</p>
                      <p className="text-muted-foreground mt-1">Lab 3</p>
                    </div>
                  </div>
                  <div className="bg-card p-3"></div>
                  <div className="bg-card p-3">
                    <div className="rounded-md bg-green-100 p-2 text-xs border-l-2 border-green-500">
                      <p className="font-medium">Biology Lab</p>
                      <p className="text-muted-foreground mt-1">Lab 3</p>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="list" className="mt-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الفصل</TableHead>
                    <TableHead>المادة</TableHead>
                    <TableHead>القاعة</TableHead>
                    <TableHead>الجدول</TableHead>
                    <TableHead>الطلاب</TableHead>
                    <TableHead className="text-right">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockClasses.map((cls) => (
                    <TableRow key={cls.id}>
                      <TableCell className="font-medium">{cls.name}</TableCell>
                      <TableCell>{cls.subject}</TableCell>
                      <TableCell>{cls.room}</TableCell>
                      <TableCell>{cls.schedule}</TableCell>
                      <TableCell>{cls.students}</TableCell>
                      <TableCell className="text-right">
                        <Button size="sm" className="mr-2 bg-edu-yellow text-foreground hover:bg-edu-yellow/90">
                          عرض
                        </Button>
                        <Button size="sm" className="bg-edu-pink hover:bg-edu-pink/90">
                          تعديل
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}