import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Search, UserPlus, FileText, Mail, Phone } from "lucide-react";
import { useState } from "react";

// Mock data
const mockStudents = [
  { id: 1, name: "Alex Johnson", email: "alex@example.com", phone: "+1 (555) 123-4567", class: "Physics Fundamentals", grade: "A", attendance: 95, avatar: "AJ" },
  { id: 2, name: "Sarah Williams", email: "sarah@example.com", phone: "+1 (555) 234-5678", class: "Advanced Mathematics", grade: "B+", attendance: 88, avatar: "SW" },
  { id: 3, name: "Michael Brown", email: "michael@example.com", phone: "+1 (555) 345-6789", class: "Biology Lab", grade: "A-", attendance: 92, avatar: "MB" },
  { id: 4, name: "Emma Davis", email: "emma@example.com", phone: "+1 (555) 456-7890", class: "Chemistry", grade: "B", attendance: 85, avatar: "ED" },
  { id: 5, name: "James Wilson", email: "james@example.com", phone: "+1 (555) 567-8901", class: "Physics Fundamentals", grade: "C+", attendance: 78, avatar: "JW" },
  { id: 6, name: "Olivia Martin", email: "olivia@example.com", phone: "+1 (555) 678-9012", class: "Advanced Mathematics", grade: "A", attendance: 96, avatar: "OM" },
  { id: 7, name: "William Garcia", email: "william@example.com", phone: "+1 (555) 789-0123", class: "Biology Lab", grade: "B-", attendance: 82, avatar: "WG" },
  { id: 8, name: "Sophia Rodriguez", email: "sophia@example.com", phone: "+1 (555) 890-1234", class: "Chemistry", grade: "A+", attendance: 98, avatar: "SR" },
];

export default function StudentsComponent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [classFilter, setClassFilter] = useState("all");
  
  const filteredStudents = mockStudents.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          student.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesClass = classFilter === "all" || student.class === classFilter;
    return matchesSearch && matchesClass;
  });
  
  return (
    <div className="space-y-6 font-[Cairo,Tajawal,sans-serif]" dir="rtl">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">الطلاب</h2>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="bg-edu-pink hover:bg-edu-pink/90">
              <UserPlus className="mr-2 h-4 w-4" />
              إضافة طالب
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>إضافة طالب جديد</DialogTitle>
              <DialogDescription>
                أدخل بيانات الطالب أدناه.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="student-name">الاسم الكامل</label>
                <Input id="student-name" placeholder="أدخل اسم الطالب" />
              </div>
              <div className="grid gap-2">
                <label htmlFor="student-email">البريد الإلكتروني</label>
                <Input id="student-email" type="email" placeholder="student@example.com" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <label htmlFor="student-phone">رقم الجوال</label>
                  <Input id="student-phone" placeholder="مثال: +966 5xxxxxxx" />
                </div>
                <div className="grid gap-2">
                  <label htmlFor="student-id">رقم الطالب</label>
                  <Input id="student-id" placeholder="مثال: S12345678" />
                </div>
              </div>
              <div className="grid gap-2">
                  <label htmlFor="student-class">تعيين للصف</label>
                <Select>
                  <SelectTrigger id="student-class">
                    <SelectValue placeholder="اختر الصف" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="physics">أساسيات الفيزياء</SelectItem>
                    <SelectItem value="mathematics">الرياضيات المتقدمة</SelectItem>
                    <SelectItem value="biology">مختبر الأحياء</SelectItem>
                    <SelectItem value="chemistry">الكيمياء</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline">إلغاء</Button>
              <Button className="bg-edu-pink hover:bg-edu-pink/90">إضافة الطالب</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Search and filter */}
      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="ابحث عن الطلاب..." 
            className="pl-8" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Select 
          defaultValue="all"
          onValueChange={(value) => setClassFilter(value)}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="الصف" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الصفوف</SelectItem>
            <SelectItem value="grade1">الصف الأول</SelectItem>
            <SelectItem value="grade2">الصف الثاني</SelectItem>
            <SelectItem value="grade3">الصف الثالث</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      {/* Student Management Tabs */}
      <Tabs defaultValue="list" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="list">عرض قائمة</TabsTrigger>
          <TabsTrigger value="grid">عرض شبكة</TabsTrigger>
        </TabsList>
        
        <TabsContent value="list" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>الاسم</TableHead>
                    <TableHead>التواصل</TableHead>
                    <TableHead>الصف</TableHead>
                    <TableHead>الدرجة</TableHead>
                    <TableHead>الحضور</TableHead>
                    <TableHead className="text-right">إجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell>
                        <div className="flex items-center space-x-3">
                          <Avatar>
                            <AvatarImage src={`https://i.pravatar.cc/150?u=${student.id}`} />
                            <AvatarFallback>{student.avatar}</AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{student.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center text-sm">
                            <Mail className="mr-1 h-3 w-3 text-muted-foreground" />
                            <span className="text-muted-foreground">{student.email}</span>
                          </div>
                          <div className="flex items-center text-sm">
                            <Phone className="mr-1 h-3 w-3 text-muted-foreground" />
                            <span className="text-muted-foreground">{student.phone}</span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={
                          student.class === 'Advanced Mathematics' 
                            ? 'bg-edu-orange text-white' 
                            : student.class === 'Biology Lab' 
                              ? 'bg-green-500 text-white' 
                              : student.class === 'Chemistry'
                                ? 'bg-edu-yellow text-foreground'
                                : 'bg-edu-yellow text-foreground'
                        }>
                          {student.class}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className={
                          student.grade.startsWith('A') 
                            ? 'text-green-600 font-medium' 
                            : student.grade.startsWith('B') 
                              ? 'text-edu-orange font-medium' 
                              : 'text-red-500 font-medium'
                        }>
                          {student.grade}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full ${
                                student.attendance >= 90 
                                  ? 'bg-green-500' 
                                  : student.attendance >= 80 
                                    ? 'bg-edu-orange' 
                                    : 'bg-red-500'
                              }`}
                              style={{ width: `${student.attendance}%` }}
                            ></div>
                          </div>
                          <span className="text-xs font-medium">{student.attendance}%</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="outline" size="sm" className="mr-2">
                          <FileText className="h-4 w-4" />
                          <span className="sr-only">عرض التقرير</span>
                        </Button>
                        <Button size="sm" className="bg-edu-pink hover:bg-edu-pink/90">
                          عرض
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="grid" className="mt-4">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredStudents.map((student) => (
              <Card key={student.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-center space-x-4">
                    <Avatar>
                      <AvatarImage src={`https://i.pravatar.cc/150?u=${student.id}`} />
                      <AvatarFallback>{student.avatar}</AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-lg">{student.name}</CardTitle>
                      <CardDescription>{student.email}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pb-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">الصف:</span>
                      <Badge className={
                        student.class === 'Advanced Mathematics' 
                          ? 'bg-edu-orange text-white' 
                          : student.class === 'Biology Lab' 
                            ? 'bg-green-500 text-white' 
                            : student.class === 'Chemistry'
                              ? 'bg-edu-yellow text-foreground'
                              : 'bg-edu-yellow text-foreground'
                      }>
                        {student.class}
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">الدرجة:</span>
                      <span className={
                        student.grade.startsWith('A') 
                          ? 'text-green-600 font-medium' 
                          : student.grade.startsWith('B') 
                            ? 'text-edu-orange font-medium' 
                            : 'text-red-500 font-medium'
                      }>
                        {student.grade}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">الحضور:</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-[60px] bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              student.attendance >= 90 
                                ? 'bg-green-500' 
                                : student.attendance >= 80 
                                  ? 'bg-edu-orange' 
                                  : 'bg-red-500'
                            }`}
                            style={{ width: `${student.attendance}%` }}
                          ></div>
                        </div>
                        <span className="text-xs font-medium">{student.attendance}%</span>
                      </div>
                    </div>
                    <div className="pt-2 flex space-x-2">
                      <Button variant="outline" className="flex-1">
                        <FileText className="mr-2 h-4 w-4" />
                        تقرير
                      </Button>
                      <Button className="flex-1 bg-edu-pink hover:bg-edu-pink/90">
                        تفاصيل
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Student Statistics */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>توزيع الطلاب على الصفوف</CardTitle>
            <CardDescription>عدد الطلاب في كل صف</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-edu-yellow mr-2"></div>
                    <span>أساسيات الفيزياء</span>
                  </div>
                  <span>24</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full">
                  <div className="h-full bg-edu-yellow rounded-full" style={{ width: '28%' }}></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-edu-orange mr-2"></div>
                    <span>الرياضيات المتقدمة</span>
                  </div>
                  <span>22</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full">
                  <div className="h-full bg-edu-orange rounded-full" style={{ width: '26%' }}></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                    <span>مختبر الأحياء</span>
                  </div>
                  <span>18</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full">
                  <div className="h-full bg-green-500 rounded-full" style={{ width: '21%' }}></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-edu-pink mr-2"></div>
                    <span>الكيمياء</span>
                  </div>
                  <span>20</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full">
                  <div className="h-full bg-edu-pink rounded-full" style={{ width: '24%' }}></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>توزيع الدرجات</CardTitle>
            <CardDescription>أداء الطلاب العام</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                    <span>ممتاز (A) 90-100%</span>
                  </div>
                  <span>34%</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full">
                  <div className="h-full bg-green-500 rounded-full" style={{ width: '34%' }}></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-edu-yellow mr-2"></div>
                    <span>جيد جداً (B) 80-89%</span>
                  </div>
                  <span>42%</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full">
                  <div className="h-full bg-edu-yellow rounded-full" style={{ width: '42%' }}></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-edu-orange mr-2"></div>
                    <span>جيد (C) 70-79%</span>
                  </div>
                  <span>18%</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full">
                  <div className="h-full bg-edu-orange rounded-full" style={{ width: '18%' }}></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                    <span>ضعيف (D وأقل) أقل من 70%</span>
                  </div>
                  <span>6%</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full">
                  <div className="h-full bg-red-500 rounded-full" style={{ width: '6%' }}></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>نظرة عامة على الحضور</CardTitle>
            <CardDescription>مؤشرات حضور الطلاب</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center">
                <div className="text-3xl font-bold">89.7%</div>
                <p className="text-sm text-muted-foreground mt-1">متوسط نسبة الحضور</p>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                    <span>ممتاز (&gt; 90%)</span>
                  </div>
                  <span>48%</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full">
                  <div className="h-full bg-green-500 rounded-full" style={{ width: '48%' }}></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-edu-yellow mr-2"></div>
                    <span>جيد جداً (80-90%)</span>
                  </div>
                  <span>32%</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full">
                  <div className="h-full bg-edu-yellow rounded-full" style={{ width: '32%' }}></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-edu-orange mr-2"></div>
                    <span>جيد (70-80%)</span>
                  </div>
                  <span>14%</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full">
                  <div className="h-full bg-edu-orange rounded-full" style={{ width: '14%' }}></div>
                </div>
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                    <span>ضعيف (&lt; 70%)</span>
                  </div>
                  <span>6%</span>
                </div>
                <div className="h-2 w-full bg-gray-100 rounded-full">
                  <div className="h-full bg-red-500 rounded-full" style={{ width: '6%' }}></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}