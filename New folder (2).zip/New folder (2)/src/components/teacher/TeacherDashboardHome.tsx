import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Calendar, Check, Clock, FileText, Users, GraduationCap } from "lucide-react";
import { Button } from "@/components/ui/button";

import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { useState } from "react";

// إضافة دالة جلب التاريخ الحالي بالعربي
function getTodayAr() {
  const today = new Date();
  const months = [
    "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
    "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
  ];
  const day = today.getDate();
  const month = months[today.getMonth()];
  const year = today.getFullYear();
  return `${day} ${month} ${year}`;
}

export default function TeacherDashboardHome() {
  const [selectedGrade, setSelectedGrade] = useState("grade1");
  const [quickAction, setQuickAction] = useState<string | null>(null);

  // بيانات افتراضية لكل صف
  const gradesData = {
    grade1: {
      name: "الصف الأول",
      students: 30,
      classes: [
        { name: "الرياضيات", teacher: "أ. أحمد", time: "10:00 ص" },
        { name: "العلوم", teacher: "أ. سارة", time: "12:00 م" },
      ],
      exams: [
        { title: "امتحان رياضيات 1", date: "2024-07-10", files: ["math1.pdf"], quiz: "كويز 1" },
        { title: "امتحان علوم 1", date: "2024-07-12", files: ["science1.pdf"], quiz: "كويز 2" },
      ],
      attendance: [
        { date: "2024-07-01", present: 28, absent: 2 },
        { date: "2024-07-02", present: 29, absent: 1 },
      ],
    },
    grade2: {
      name: "الصف الثاني",
      students: 28,
      classes: [
        { name: "اللغة العربية", teacher: "أ. منى", time: "9:00 ص" },
        { name: "الفيزياء", teacher: "أ. خالد", time: "11:00 ص" },
      ],
      exams: [
        { title: "امتحان عربي 2", date: "2024-07-11", files: ["arabic2.pdf"], quiz: "كويز 1" },
        { title: "امتحان فيزياء 2", date: "2024-07-13", files: ["physics2.pdf"], quiz: "كويز 2" },
      ],
      attendance: [
        { date: "2024-07-01", present: 27, absent: 1 },
        { date: "2024-07-02", present: 28, absent: 0 },
      ],
    },
    grade3: {
      name: "الصف الثالث",
      students: 29,
      classes: [
        { name: "الإنجليزي", teacher: "أ. هالة", time: "8:00 ص" },
        { name: "الكيمياء", teacher: "أ. سامي", time: "10:00 ص" },
      ],
      exams: [
        { title: "امتحان إنجليزي 3", date: "2024-07-14", files: ["eng3.pdf"], quiz: "كويز 1" },
        { title: "امتحان كيمياء 3", date: "2024-07-16", files: ["chem3.pdf"], quiz: "كويز 2" },
      ],
      attendance: [
        { date: "2024-07-01", present: 29, absent: 0 },
        { date: "2024-07-02", present: 28, absent: 1 },
      ],
    },
  };
  const grade = gradesData[selectedGrade];

  // دوال الإجراءات السريعة
  const handleQuickAction = (action: string) => {
    setQuickAction(action);
  };

  const closeDialog = () => setQuickAction(null);

  return (
    <div className="space-y-6 font-[Cairo,Tajawal,sans-serif]" dir="rtl">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">لوحة تحكم المعلم</h2>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="bg-edu-yellow/20 text-edu-orange border-edu-yellow">
            <Calendar className="mr-1 h-3 w-3" />
            {getTodayAr()}
          </Badge>
        </div>
      </div>

      {/* Tabs للصفوف */}
      <Tabs value={selectedGrade} onValueChange={setSelectedGrade} className="mb-4">
        <TabsList>
          <TabsTrigger value="grade1">الصف الأول</TabsTrigger>
          <TabsTrigger value="grade2">الصف الثاني</TabsTrigger>
          <TabsTrigger value="grade3">الصف الثالث</TabsTrigger>
        </TabsList>
      </Tabs>

      

      {/* البطاقات + كارد الإجراءات السريعة */}
      <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-4">
        {/* كارد إجمالي الطلاب */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">إجمالي الطلاب</CardTitle>
            <Users className="h-4 w-4 text-edu-orange" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{grade.students}</div>
            <p className="text-xs text-muted-foreground">في هذا الصف</p>
          </CardContent>
        </Card>
        {/* كارد الحصص */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">الحصص</CardTitle>
            <GraduationCap className="h-4 w-4 text-edu-orange" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{grade.classes.length}</div>
            <p className="text-xs text-muted-foreground">عدد الحصص لهذا الصف</p>
          </CardContent>
        </Card>
        {/* كارد الإجراءات السريعة */}
        <Card className="md:col-span-1 lg:col-span-2 flex flex-col justify-between">
          <CardHeader>
            <CardTitle>إجراءات سريعة</CardTitle>
            <CardDescription>مهام يمكنك تنفيذها بسرعة</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Button
                className="h-auto py-4 px-2 bg-edu-orange text-white hover:bg-edu-orange/90"
                onClick={() => handleQuickAction("take-attendance")}
              >
                <div className="flex flex-col items-center">
                  <Calendar className="h-5 w-5 mb-1" />
                  <span>تسجيل الحضور</span>
                </div>
              </Button>
              <Button
                className="h-auto py-4 px-2 bg-edu-pink text-white hover:bg-edu-pink/90"
                onClick={() => handleQuickAction("student-reports")}
              >
                <div className="flex flex-col items-center">
                  <Users className="h-5 w-5 mb-1" />
                  <span>تقارير الطلاب</span>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* الأنشطة الحديثة */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>الأنشطة الحديثة</CardTitle>
            <CardDescription>آخر التحديثات من الصفوف</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="bg-green-100 p-2 rounded-full">
                  <Check className="h-4 w-4 text-green-600" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-bold">تم تسجيل الحضور</p>
                  <p className="text-xs text-muted-foreground">تم تسجيل الحضور في حصة أساسيات الفيزياء</p>
                  <p className="text-xs text-edu-orange">منذ 3 ساعات</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="bg-edu-pink/20 p-2 rounded-full">
                  <Users className="h-4 w-4 text-edu-pink" />
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-bold">طالب جديد تم إضافته</p>
                  <p className="text-xs text-muted-foreground">انضمت سارة جونسون إلى صف الأحياء</p>
                  <p className="text-xs text-edu-orange">منذ يوم</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      {/* نافذة الإجراءات السريعة */}
      <Dialog open={!!quickAction} onOpenChange={closeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {quickAction === "take-attendance" && "تسجيل الحضور"}
              {quickAction === "student-reports" && "تقارير الطلاب"}
            </DialogTitle>
            <DialogDescription>
              {quickAction === "take-attendance" && "سجل حضور الطلاب للصفوف."}
              {quickAction === "student-reports" && "استعرض تقارير أداء الطلاب."}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={closeDialog}>إغلاق</Button>
            {quickAction === "take-attendance" && (
              <Button onClick={() => { alert("تم تسجيل الحضور!"); closeDialog(); }}>تسجيل</Button>
            )}
            {quickAction === "student-reports" && (
              <Button onClick={() => { alert("عرض التقارير!"); closeDialog(); }}>عرض</Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Card className="mb-4">
        <CardHeader>
          <CardTitle className="text-xl font-bold">{grade.name}</CardTitle>
          <CardDescription>عدد الطلاب: {grade.students}</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="classes" className="w-full">
            <TabsList className="mb-4 grid grid-cols-5">
              <TabsTrigger value="classes">الحصص</TabsTrigger>
              <TabsTrigger value="students">الطلاب</TabsTrigger>
              <TabsTrigger value="exams">الامتحانات</TabsTrigger>
              <TabsTrigger value="attendance">الحضور</TabsTrigger>
              <TabsTrigger value="lectures">المحاضرات</TabsTrigger>
            </TabsList>
            <TabsContent value="classes">
              {/* ...existing code... */}
            </TabsContent>
            <TabsContent value="students">
              {/* ...existing code... */}
            </TabsContent>
            <TabsContent value="exams">
              <div className="space-y-2">
                <Button className="mb-3 bg-edu-orange text-white" onClick={() => alert("إنشاء امتحان جديد")}>
                  إنشاء امتحان جديد للصف {grade.name}
                </Button>
                <Button className="mb-3 bg-edu-purple text-white ml-2" onClick={() => alert("رفع ملف امتحان")}>
                  رفع ملف امتحان للصف {grade.name}
                </Button>
                <Button className="mb-3 bg-edu-pink text-white ml-2" onClick={() => alert("إنشاء كويز قصير")}>
                  إنشاء كويز قصير للصف {grade.name}
                </Button>
                {grade.exams.map((exam, idx) => (
                  <div key={idx} className="flex flex-col gap-2 p-3 border rounded-lg mb-2">
                    <span className="font-bold">{exam.title}</span>
                    <span className="text-sm text-muted-foreground">تاريخ الامتحان: {exam.date}</span>
                    <span className="text-sm text-muted-foreground">الملفات: {exam.files.join(", ")}</span>
                    <span className="text-sm text-muted-foreground">الكويز: {exam.quiz}</span>
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="attendance">
              {/* ...existing code... */}
            </TabsContent>
            <TabsContent value="lectures">
              <div className="space-y-2">
                <Button className="mb-3 bg-edu-purple text-white" onClick={() => alert("رفع محاضرة جديدة")}>
                  رفع محاضرة جديدة
                </Button>
                <div className="text-muted-foreground text-sm">لا توجد محاضرات مرفوعة بعد.</div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}