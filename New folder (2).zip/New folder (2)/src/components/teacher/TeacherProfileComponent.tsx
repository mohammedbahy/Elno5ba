import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalendarIcon, Mail, MapPin, Phone, School, Pencil, User, BookOpen, Award, Clock, Calendar, Plus } from "lucide-react";
import { useState } from "react";

export default function TeacherProfileComponent() {
  const [isEditing, setIsEditing] = useState(false);

  const teacherProfile = {
    id: "T12345",
    name: "Dr. Sarah Johnson",
    email: "sarah.johnson@eduplatform.com",
    phone: "+1 (555) 234-5678",
    avatar: "SJ",
    address: "123 University Ave, Los Angeles, CA 90007",
    department: "Science Department",
    title: "Senior Physics Teacher",
    bio: "Ph.D. in Theoretical Physics with over 15 years of teaching experience. Specializes in modern physics and quantum mechanics. Passionate about making complex concepts accessible to students and fostering scientific curiosity.",
    education: [
      { degree: "Ph.D. in Theoretical Physics", institution: "California Institute of Technology", year: "2010" },
      { degree: "M.Sc. in Physics", institution: "Stanford University", year: "2006" },
      { degree: "B.Sc. in Physics", institution: "University of California, Berkeley", year: "2004" }
    ],
    subjects: ["Physics Fundamentals", "Advanced Physics", "Quantum Mechanics", "Astronomy"],
    certifications: ["National Board Certified Teacher", "Advanced Placement Physics Instructor", "STEM Education Leadership Certificate"],
    teachingHours: 24,
    joinDate: new Date(2015, 7, 15), // August 15, 2015
    achievements: [
      "Teacher of the Year (2023)",
      "Science Department Head (2020-Present)",
      "Published Author: 'Making Physics Fun' (2019)",
      "Research Grant Recipient (2018)"
    ],
    skills: ["Curriculum Development", "Laboratory Instruction", "Educational Technology", "Student Mentoring", "Research Methods"]
  };
  
  return (
    <div className="space-y-6 font-[Cairo,Tajawal,sans-serif]" dir="rtl">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">الملف الشخصي للمعلم</h2>
        <Button 
          variant="outline"
          className="gap-1"
          onClick={() => setIsEditing(!isEditing)}
        >
          <Pencil className="h-4 w-4" />
          {isEditing ? "إلغاء التعديل" : "تعديل الملف"}
        </Button>
      </div>
      
      <Tabs defaultValue="info" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="info">المعلومات الشخصية</TabsTrigger>
          <TabsTrigger value="credentials">المؤهلات</TabsTrigger>
          <TabsTrigger value="schedule">الجدول والسيرة</TabsTrigger>
        </TabsList>
        
        <TabsContent value="info" className="mt-4 space-y-6">
          {/* Profile Card */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src="https://i.pravatar.cc/96?img=32" />
                    <AvatarFallback className="text-2xl">{teacherProfile.avatar}</AvatarFallback>
                  </Avatar>
                  {isEditing && (
                    <Button size="sm" variant="secondary" className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 p-0">
                      <Pencil className="h-4 w-4" />
                      <span className="sr-only">Change Avatar</span>
                    </Button>
                  )}
                </div>
                <div className="space-y-1">
                  <CardTitle className="text-2xl">{teacherProfile.name}</CardTitle>
                  <CardDescription className="flex flex-col space-y-1">
                    <span className="flex items-center gap-1">
                      <Badge className="bg-edu-purple text-white">{teacherProfile.title}</Badge>
                    </span>
                    <span className="flex items-center gap-1">
                      <School className="h-3 w-3 text-muted-foreground" />
                      <span className="text-muted-foreground">{teacherProfile.department}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <User className="h-3 w-3 text-muted-foreground" />
                      <span className="text-muted-foreground">ID: {teacherProfile.id}</span>
                    </span>
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <Separator />
            <CardContent className="pt-4">
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">معلومات التواصل</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      {isEditing ? (
                        <div className="space-y-2">
                          <Label htmlFor="email">البريد الإلكتروني</Label>
                          <Input id="email" defaultValue={teacherProfile.email} />
                        </div>
                      ) : (
                        <div className="flex items-center space-x-2">
                          <Mail className="h-4 w-4 text-muted-foreground" />
                          <span>{teacherProfile.email}</span>
                        </div>
                      )}
                    </div>
                    <div className="space-y-2">
                      {isEditing ? (
                        <div className="space-y-2">
                          <Label htmlFor="phone">رقم الجوال</Label>
                          <Input id="phone" defaultValue={teacherProfile.phone} />
                        </div>
                      ) : (
                        <div className="flex items-center space-x-2">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                          <span>{teacherProfile.phone}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="mt-2">
                    {isEditing ? (
                      <div className="space-y-2">
                        <Label htmlFor="address">العنوان</Label>
                        <Input id="address" defaultValue={teacherProfile.address} />
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>{teacherProfile.address}</span>
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">نبذة مهنية</h3>
                  {isEditing ? (
                    <div className="space-y-2">
                      <Label htmlFor="bio">السيرة المهنية</Label>
                      <Textarea id="bio" defaultValue={teacherProfile.bio} rows={4} />
                    </div>
                  ) : (
                    <p>{teacherProfile.bio}</p>
                  )}
                </div>
              </div>
            </CardContent>
            {isEditing && (
              <CardFooter className="flex justify-end space-x-2 border-t pt-4">
                <Button variant="outline">Cancel</Button>
                <Button className="bg-edu-orange hover:bg-edu-orange/90">Save Changes</Button>
              </CardFooter>
            )}
          </Card>
          
          {/* Skills & Subjects Card */}
          <Card>
            <CardHeader>
              <CardTitle>المهارات والمجالات التدريسية</CardTitle>
              <CardDescription>الخبرات المهنية والمواد التي يتم تدريسها</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium mb-2">المواد التي يتم تدريسها</h3>
                  {isEditing ? (
                    <div className="space-y-2">
                      <Label htmlFor="subjects">المواد الحالية (مفصولة بفاصلة)</Label>
                      <Input id="subjects" defaultValue={teacherProfile.subjects.join(", ")} />
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {teacherProfile.subjects.map((subject, index) => (
                        <Badge key={index} className="bg-edu-yellow text-foreground">
                          <BookOpen className="mr-1 h-3 w-3" />
                          {subject}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
                
                <div>
                  <h3 className="font-medium mb-2">المهارات المهنية</h3>
                  {isEditing ? (
                    <div className="space-y-2">
                      <Label htmlFor="skills">المهارات المهنية (مفصولة بفاصلة)</Label>
                      <Input id="skills" defaultValue={teacherProfile.skills.join(", ")} />
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {teacherProfile.skills.map((skill, index) => (
                        <Badge key={index} variant="outline">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
                
                <div>
                  <h3 className="font-medium mb-2">الإنجازات</h3>
                  {isEditing ? (
                    <div className="space-y-2">
                      <Label htmlFor="achievements">الإنجازات المهنية</Label>
                      <Textarea id="achievements" defaultValue={teacherProfile.achievements.join("\n")} rows={4} />
                    </div>
                  ) : (
                    <ul className="list-disc list-inside space-y-1">
                      {teacherProfile.achievements.map((achievement, index) => (
                        <li key={index} className="text-sm">
                          <span className="text-muted-foreground">{achievement}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            </CardContent>
            {isEditing && (
              <CardFooter className="flex justify-end space-x-2 border-t pt-4">
                <Button variant="outline">Cancel</Button>
                <Button className="bg-edu-orange hover:bg-edu-orange/90">Save Changes</Button>
              </CardFooter>
            )}
          </Card>
        </TabsContent>
        
        <TabsContent value="credentials" className="mt-4 space-y-6">
          <Card>
            <CardHeader>
            <CardTitle>الخلفية التعليمية</CardTitle>
            <CardDescription>المؤهلات الأكاديمية والشهادات</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {isEditing ? (
                  <div className="space-y-4">
                    {teacherProfile.education.map((edu, index) => (
                      <div key={index} className="grid grid-cols-1 md:grid-cols-3 gap-3 p-3 border rounded-lg">
                        <div className="space-y-2">
                          <Label htmlFor={`degree-${index}`}>الدرجة العلمية</Label>
                          <Input id={`degree-${index}`} defaultValue={edu.degree} />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor={`institution-${index}`}>المؤسسة</Label>
                          <Input id={`institution-${index}`} defaultValue={edu.institution} />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor={`year-${index}`}>السنة</Label>
                          <Input id={`year-${index}`} defaultValue={edu.year} />
                        </div>
                      </div>
                    ))}
                    <Button variant="outline" className="w-full">
                      <Plus className="mr-2 h-4 w-4" />
                      إضافة مؤهل
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {teacherProfile.education.map((edu, index) => (
                      <div key={index} className="flex flex-col p-3 border rounded-lg">
                        <div className="flex justify-between items-start">
                          <div className="space-y-1">
                            <div className="font-medium">{edu.degree}</div>
                            <div className="text-sm text-muted-foreground">{edu.institution}</div>
                          </div>
                          <Badge variant="outline">{edu.year}</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
            <Separator />
            <CardHeader>
            <CardTitle>الشهادات المهنية</CardTitle>
            <CardDescription>رخص التدريس والشهادات المتخصصة</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {isEditing ? (
                  <div className="space-y-2">
                    <Label htmlFor="certifications">الشهادات (كل شهادة في سطر)</Label>
                    <Textarea id="certifications" defaultValue={teacherProfile.certifications.join("\n")} rows={3} />
                    <Button variant="outline" className="w-full mt-2">
                      <Plus className="mr-2 h-4 w-4" />
                      إضافة شهادة
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {teacherProfile.certifications.map((cert, index) => (
                      <div key={index} className="flex items-center p-2 border rounded-lg">
                        <Award className="h-4 w-4 text-edu-orange mr-2" />
                        <span>{cert}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </CardContent>
            {isEditing && (
              <CardFooter className="flex justify-end space-x-2 border-t pt-4">
                <Button variant="outline">Cancel</Button>
                <Button className="bg-edu-orange hover:bg-edu-orange/90">Save Changes</Button>
              </CardFooter>
            )}
          </Card>
        </TabsContent>
        
        <TabsContent value="schedule" className="mt-4 space-y-6">
          <Card>
            <CardHeader>
            <CardTitle>نظرة عامة على الجدول</CardTitle>
            <CardDescription>ساعات التدريس الأسبوعية والمهام</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="border rounded-lg p-4 text-center">
                    <div className="flex justify-center mb-2">
                      <div className="p-2 rounded-full bg-edu-yellow/20">
                        <Clock className="h-6 w-6 text-edu-orange" />
                      </div>
                    </div>
                    <div className="text-2xl font-bold">{teacherProfile.teachingHours}</div>
                    <div className="text-sm text-muted-foreground">ساعات التدريس الأسبوعية</div>
                  </div>
                  <div className="border rounded-lg p-4 text-center">
                    <div className="flex justify-center mb-2">
                      <div className="p-2 rounded-full bg-edu-pink/20">
                        <BookOpen className="h-6 w-6 text-edu-pink" />
                      </div>
                    </div>
                    <div className="text-2xl font-bold">{teacherProfile.subjects.length}</div>
                    <div className="text-sm text-muted-foreground">عدد المواد التي يتم تدريسها</div>
                  </div>
                  <div className="border rounded-lg p-4 text-center">
                    <div className="flex justify-center mb-2">
                      <div className="p-2 rounded-full bg-edu-purple/20">
                        <Calendar className="h-6 w-6 text-edu-purple" />
                      </div>
                    </div>
                    <div className="text-2xl font-bold">{new Date().getFullYear() - teacherProfile.joinDate.getFullYear()}</div>
                    <div className="text-sm text-muted-foreground">سنوات العمل بالمؤسسة</div>
                  </div>
                </div>
                
                <div className="pt-4">
                  <h3 className="text-lg font-semibold mb-4">الجدول الأسبوعي</h3>
                  <div className="rounded-lg border overflow-hidden">
                    <div className="grid grid-cols-6 gap-px bg-muted">
                      <div className="bg-card p-3"></div>
                      <div className="bg-card p-3 text-center text-xs font-medium">الاثنين</div>
                      <div className="bg-card p-3 text-center text-xs font-medium">الثلاثاء</div>
                      <div className="bg-card p-3 text-center text-xs font-medium">الأربعاء</div>
                      <div className="bg-card p-3 text-center text-xs font-medium">الخميس</div>
                      <div className="bg-card p-3 text-center text-xs font-medium">الجمعة</div>
                    </div>
                    
                    {/* 10:00 AM Row */}
                    <div className="grid grid-cols-6 gap-px bg-muted">
                      <div className="bg-card p-3 text-center text-xs font-medium">10:00 ص</div>
                      <div className="bg-card p-3">
                        <div className="rounded-md bg-edu-yellow/20 p-2 text-xs border-l-2 border-edu-yellow">
                          <p className="font-medium">أساسيات الفيزياء</p>
                          <p className="text-muted-foreground mt-1">القاعة 101</p>
                        </div>
                      </div>
                      <div className="bg-card p-3"></div>
                      <div className="bg-card p-3">
                        <div className="rounded-md bg-edu-yellow/20 p-2 text-xs border-l-2 border-edu-yellow">
                          <p className="font-medium">Physics Fundamentals</p>
                          <p className="text-muted-foreground mt-1">Room 101</p>
                        </div>
                      </div>
                      <div className="bg-card p-3"></div>
                      <div className="bg-card p-3">
                        <div className="rounded-md bg-edu-yellow/20 p-2 text-xs border-l-2 border-edu-yellow">
                          <p className="font-medium">Physics Fundamentals</p>
                          <p className="text-muted-foreground mt-1">Room 101</p>
                        </div>
                      </div>
                    </div>
                    
                    {/* 12:00 PM Row */}
                    <div className="grid grid-cols-6 gap-px bg-muted">
                      <div className="bg-card p-3 text-center text-xs font-medium">12:00 م</div>
                      <div className="bg-card p-3"></div>
                      <div className="bg-card p-3">
                        <div className="rounded-md bg-green-100 p-2 text-xs border-l-2 border-green-500">
                          <p className="font-medium">الفيزياء المتقدمة</p>
                          <p className="text-muted-foreground mt-1">القاعة 204</p>
                        </div>
                      </div>
                      <div className="bg-card p-3"></div>
                      <div className="bg-card p-3">
                        <div className="rounded-md bg-green-100 p-2 text-xs border-l-2 border-green-500">
                          <p className="font-medium">Advanced Physics</p>
                          <p className="text-muted-foreground mt-1">Room 204</p>
                        </div>
                      </div>
                      <div className="bg-card p-3"></div>
                      
                    </div>
                    
                    {/* 2:00 PM Row */}
                    <div className="grid grid-cols-6 gap-px bg-muted">
                      <div className="bg-card p-3 text-center text-xs font-medium">2:00 م</div>
                      <div className="bg-card p-3"></div>
                      <div className="bg-card p-3"></div>
                      <div className="bg-card p-3">
                        <div className="rounded-md bg-edu-purple/20 p-2 text-xs border-l-2 border-edu-purple">
                          <p className="font-medium">ميكانيكا الكم</p>
                          <p className="text-muted-foreground mt-1">المعمل 3</p>
                        </div>
                      </div>
                      <div className="bg-card p-3"></div>
                      <div className="bg-card p-3">
                        <div className="rounded-md bg-edu-purple/20 p-2 text-xs border-l-2 border-edu-purple">
                          <p className="font-medium">Quantum Mechanics</p>
                          <p className="text-muted-foreground mt-1">Lab 3</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
            <CardTitle>الخبرات الوظيفية</CardTitle>
            <CardDescription>الخبرة المهنية في التدريس</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="relative pl-6 pb-6 border-l-2 border-muted">
                  <div className="absolute w-3 h-3 bg-edu-orange rounded-full -left-[7px]"></div>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold">معلم فيزياء أول</h3>
                      <Badge className="bg-edu-yellow text-foreground">حالي</Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">أكاديمية منصة التعليم</div>
                    <div className="text-sm">2020 - الآن</div>
                    <p className="text-sm text-muted-foreground mt-2">
                      تدريس مقررات الفيزياء المتقدمة وتطوير مناهج قسم العلوم.
                    </p>
                  </div>
                </div>
                
                <div className="relative pl-6 pb-6 border-l-2 border-muted">
                  <div className="absolute w-3 h-3 bg-muted rounded-full -left-[7px]"></div>
                  <div className="space-y-1">
                    <h3 className="font-semibold">معلم فيزياء</h3>
                    <div className="text-sm text-muted-foreground">أكاديمية منصة التعليم</div>
                    <div className="text-sm">2015 - 2020</div>
                    <p className="text-sm text-muted-foreground mt-2">
                      تدريس مقررات الفيزياء التمهيدية وتأسيس نادي الفلك.
                    </p>
                  </div>
                </div>
                
                <div className="relative pl-6">
                  <div className="absolute w-3 h-3 bg-muted rounded-full -left-[7px]"></div>
                  <div className="space-y-1">
                    <h3 className="font-semibold">مساعد باحث</h3>
                    <div className="text-sm text-muted-foreground">معهد كاليفورنيا للتقنية</div>
                    <div className="text-sm">2010 - 2015</div>
                    <p className="text-sm text-muted-foreground mt-2">
                      إجراء أبحاث في الفيزياء النظرية والمساعدة في مختبرات الفيزياء الجامعية.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}