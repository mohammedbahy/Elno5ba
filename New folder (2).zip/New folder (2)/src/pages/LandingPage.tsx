import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';

const FeatureCard = ({ 
  title, 
  description, 
  icon 
}: { 
  title: string; 
  description: string; 
  icon: React.ReactNode;
}) => (
  <Card className="border-2 border-border hover:border-edu-orange hover:shadow-lg edu-transition font-[Cairo,Tajawal,sans-serif]" dir="rtl">
    <CardHeader>
      <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-edu-yellow text-foreground">
        {icon}
      </div>
      <CardTitle className="text-xl text-edu-orange">{title}</CardTitle>
    </CardHeader>
    <CardContent>
      <CardDescription className="text-base">{description}</CardDescription>
    </CardContent>
  </Card>
);

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#eaf6fb] via-[#d4ecf7] to-[#b3e0f7] flex flex-col font-[Cairo,Tajawal,sans-serif]">
      {/* هيدر كبير */}
      <header className="w-full px-8 py-3 flex flex-col md:flex-row items-center justify-between bg-gradient-to-r from-[#eaf6fb] via-[#b3e0f7] to-[#00B6F0]">
        {/* اللوجو على اليمين وصغير نسبياً */}
        <div className="flex items-center gap-4 mb-2 md:mb-0">
          <div className="w-16 h-16 rounded-full bg-edu-yellow flex items-center justify-center shadow-lg">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
              <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
            </svg>
          </div>
        </div>
        {/* أزرار التسجيل على يمين الهيدر */}
        <div className="flex items-center gap-4 md:order-2 animate-auth-btns">
          <Button variant="ghost" className="text-lg flex items-center gap-2 px-3 text-[#0077b6] hover:bg-[#eaf6fb]" asChild>
            <Link to="/login">
              <span className="flex items-center gap-1">
                <span className="font-bold text-edu-orange">سجل دخولك</span>
                <svg width="20" height="20" fill="none" stroke="#c89c1c" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24">
                  <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4z"></path>
                  <path d="M6 20v-2a4 4 0 0 1 8 0v2"></path>
                </svg>
              </span>
            </Link>
          </Button>
          <Button className="bg-[#00B6F0] hover:bg-[#009ee3] text-white text-lg px-6 py-2 rounded-xl shadow flex items-center gap-2 font-bold border-2 border-[#b3e0f7]" asChild>
            <Link to="/register">
              <span className="flex items-center gap-2">
                عمل حساب جديد
                <svg width="22" height="22" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24">
                  <rect x="3" y="3" width="18" height="18" rx="4"></rect>
                  <path d="M12 8v8M8 12h8"></path>
                  <path d="M16 16l4 4"></path>
                </svg>
              </span>
            </Link>
          </Button>
        </div>
        {/* أنيميشن للأزرار */}
        <style>
          {`
            @keyframes auth-btns-appear {
              0% { opacity: 0; transform: translateX(40px) scale(0.95);}
              60% { opacity: 1; transform: translateX(-8px) scale(1.05);}
              100% { opacity: 1; transform: translateX(0) scale(1);}
            }
            .animate-auth-btns {
              animation: auth-btns-appear 1.1s cubic-bezier(.7,.2,.3,1) both;
            }
            /* إخفاء الخط الفاصل بين الهيدر والبار */
            header {
              border-bottom: none !important;
              box-shadow: none !important;
            }
          `}
        </style>
      </header>
      
      {/* قسم رئيسي مطابق للصورة */}
      <section className="py-12 flex flex-col items-center justify-center bg-transparent relative overflow-hidden">
        <div className="flex flex-col md:flex-row-reverse items-center justify-center gap-4 w-full max-w-6xl mx-auto">
          {/* خلفية SVG احترافية وجذابة خلف صورة الطالب - يمين قليلاً */}
          <div className="absolute inset-0 flex items-center justify-end pointer-events-none z-0 animate-bg-fade">
            <svg width="700" height="480" viewBox="0 0 700 480" fill="none" xmlns="http://www.w3.org/2000/svg" className="mr-[8vw]">
              <ellipse cx="350" cy="240" rx="320" ry="180" fill="#00B6F0" opacity="0.13"/>
              <path d="M80 380 Q350 480 620 380" stroke="#00B6F0" strokeWidth="4" fill="none" opacity="0.18"/>
              <circle cx="120" cy="120" r="32" fill="#00B6F0" opacity="0.18"/>
              <rect x="540" y="60" width="60" height="24" rx="12" fill="#00B6F0" opacity="0.18"/>
              <rect x="180" y="400" width="80" height="18" rx="9" fill="#00B6F0" opacity="0.18"/>
              {/* رموز تعليمية */}
              <g>
                <text x="100" y="440" fontSize="32" fill="#00B6F0" fontFamily="Cairo,Tajawal,sans-serif">📘</text>
                <text x="600" y="120" fontSize="32" fill="#00B6F0" fontFamily="Cairo,Tajawal,sans-serif">🧪</text>
                <text x="340" y="60" fontSize="32" fill="#00B6F0" fontFamily="Cairo,Tajawal,sans-serif">🎓</text>
              </g>
              {/* خطوط متقطعة */}
              <path d="M120 120 Q200 200 350 120 Q500 40 600 120" stroke="#00B6F0" strokeWidth="2" fill="none" strokeDasharray="8 8" opacity="0.18"/>
            </svg>
          </div>
          {/* صورة 3D في منتصف القسم */}
          <div className="relative flex-shrink-0 flex items-center justify-center w-full md:w-1/2 z-10 md:justify-center animate-img-fade">
            <img
              src="https://i.postimg.cc/FKypSn1q/3d-travel-icon-with-couple.png"
              alt="Student high school 3d"
              className="w-full max-w-[650px] h-auto object-contain animate-elite-img mx-auto"
              style={{animationDelay: '0.1s'}}
            />
          </div>
          {/* نص وعنوان على الشمال مع تقليل الفراغ */}
          <div className="flex flex-col items-start justify-center gap-2 w-full md:w-1/2 z-10 md:justify-center">
            <h1 className="flex flex-col items-start mb-2">
              <span className="flex items-center gap-4">
                <span
                  className="font-bold text-5xl md:text-6xl text-[#0077b6]"
                  style={{fontFamily:'Cairo, Tajawal, sans-serif'}}
                >منصة</span>
                <span
                  className="font-extrabold text-6xl md:text-[80px] text-[#00B6F0]"
                  style={{fontFamily:'BasselFontBold, Cairo, Tajawal, sans-serif', letterSpacing:'-2px', lineHeight:'1.1'}}
                >النخبة</span>
              </span>
            </h1>
            <span
              className="text-xl md:text-2xl text-[#0077b6] font-bold mt-2"
              style={{fontFamily:'Cairo, Tajawal, sans-serif'}}
            >منصة متكاملة بها كل ما يحتاجه الطالب ليتفوق</span>
          </div>
        </div>
      </section>
      {/* إضافة أنيميشن CSS للكتابة الطبيعية */}
      <style>
        {`
          @keyframes elite-img-appear {
            0% { opacity: 0; transform: scale(0.7) rotate(-8deg);}
            40% { opacity: 1; transform: scale(1.08) rotate(3deg);}
            60% { opacity: 1; transform: scale(0.97) rotate(-2deg);}
            80% { opacity: 1; transform: scale(1.03) rotate(1deg);}
            100% { opacity: 1; transform: scale(1) rotate(0);}
          }
          .animate-elite-img {
            animation: elite-img-appear 1.5s cubic-bezier(.7,.2,.3,1) both;
          }
          @keyframes fade-in {
            0% { opacity: 0; }
            100% { opacity: 1; }
          }
          .animate-bg-fade, .animate-img-fade {
            animation: fade-in 1.2s cubic-bezier(.7,.2,.3,1) both;
          }
          .typewriter {
            display: inline-block;
            min-width: 1ch;
            border-right: 2px solid #00B6F0;
            white-space: nowrap;
            overflow: hidden;
            font-variant-ligatures: none;
          }
        `}
      </style>
      {/* كتابة طبيعية للكلام عند الدخول */}
      <script dangerouslySetInnerHTML={{
        __html: `
          function typeWriter(elementId, text, speed, delay = 0) {
            const el = document.getElementById(elementId);
            if (!el) return;
            el.textContent = '';
            setTimeout(() => {
              let i = 0;
              function typing() {
                if (i < text.length) {
                  el.textContent += text.charAt(i);
                  i++;
                  setTimeout(typing, speed);
                } else {
                  el.style.borderRight = 'none';
                }
              }
              typing();
            }, delay);
          }
          window.addEventListener('DOMContentLoaded', function() {
            typeWriter('typewriter1', 'منصة', 90, 200);
            typeWriter('typewriter2', 'النخبة', 90, 900);
            typeWriter('typewriter3', 'منصة متكاملة بها كل ما يحتاجه الطالب ليتفوق', 40, 1700);
          });
        `
      }} />
      
      {/* مميزات بشكل كروت مع هوفر احترافي لعرض التفاصيل */}
      <section className="py-16 bg-gradient-to-br from-[#eaf6fb] via-[#b3e0f7] to-[#00B6F0]" id="features">
        <div className="edu-container space-y-12">
          <div className="text-center space-y-4 max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-[#0077b6]">مميزات المنصة</h2>
            <p className="text-[#009ee3] text-lg">كل الأدوات التي يحتاجها الطالب في مكان واحد.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 justify-center">
            {[
              {
                title: "محاضرات مسجلة",
                about: "تشمل فيديوهات تفاعلية، ملخصات، وإمكانية البحث داخل المحاضرة.",
                icon: (
                  <div className="flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-tr from-[#00B6F0] to-[#7C3AED] shadow-lg">
                    <svg width="44" height="44" viewBox="0 0 32 32" fill="none">
                      <circle cx="16" cy="16" r="14" fill="#fff" />
                      <polygon points="13,11 23,16 13,21" fill="#00B6F0" />
                      <rect x="6" y="10" width="4" height="12" rx="2" fill="#7C3AED" />
                    </svg>
                  </div>
                )
              },
              {
                title: "الحضور",
                about: "تنبيهات تلقائية، تقارير حضور، ومتابعة أولياء الأمور.",
                icon: (
                  <div className="flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-tr from-[#FFD600] to-[#FF5A8A] shadow-lg">
                    <svg width="44" height="44" viewBox="0 0 32 32" fill="none">
                      <ellipse cx="16" cy="13" rx="6" ry="6" fill="#FFD600" />
                      <rect x="8" y="22" width="16" height="6" rx="3" fill="#FF5A8A" />
                      <circle cx="25" cy="8" r="3" fill="#FFD600" />
                    </svg>
                  </div>
                )
              },
              {
                title: "اختبارات أونلاين",
                about: "نماذج متنوعة، تصحيح تلقائي، مراجعة الإجابات، وتحليل نقاط القوة.",
                icon: (
                  <div className="flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-tr from-[#7C3AED] to-[#00B6F0] shadow-lg">
                    <svg width="44" height="44" viewBox="0 0 32 32" fill="none">
                      <rect x="8" y="8" width="16" height="16" rx="4" fill="#7C3AED" />
                      <path d="M12 14h8M12 18h8" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
                      <circle cx="24" cy="12" r="2" fill="#00B6F0" />
                    </svg>
                  </div>
                )
              },
              {
                title: "نظام دفع إلكتروني",
                about: "دعم جميع وسائل الدفع، فواتير إلكترونية، وإشعارات تلقائية.",
                icon: (
                  <div className="flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-tr from-[#FF5A8A] to-[#FFD600] shadow-lg">
                    <svg width="44" height="44" viewBox="0 0 32 32" fill="none">
                      <rect x="6" y="10" width="20" height="12" rx="4" fill="#FF5A8A" />
                      <circle cx="16" cy="16" r="3" fill="#FFD600" />
                      <rect x="10" y="22" width="12" height="2" rx="1" fill="#fff" />
                    </svg>
                  </div>
                )
              }
            ].map((feature, idx) => (
              <div
                key={feature.title}
                className="group relative bg-white border-2 border-edu-purple/10 rounded-xl p-6 flex flex-col items-center justify-center shadow-md hover:shadow-2xl transition-all duration-300 cursor-pointer overflow-hidden"
                style={{minHeight: 240}}
              >
                {/* محتوى الكارت الأساسي */}
                <div className="mb-2">{feature.icon}</div>
                <h3 className="text-xl font-bold text-edu-purple mb-2 group-hover:opacity-0 transition-all duration-300">{feature.title}</h3>
                {/* اباوت تغطي الكارت بالكامل عند الهوفر */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 group-hover:scale-100 scale-95 transition-all duration-400 bg-[#142A4A] text-white rounded-xl px-6 py-6 text-center text-base font-bold shadow-lg pointer-events-none z-10">
                  {feature.about}
                </div>
              </div>
            ))}
          </div>
        </div>
        {/* أنيميشن كروت المميزات */}
        <style>
          {`
            .group:hover .group-hover\\:opacity-100 {
              opacity: 1 !important;
            }
            .group:hover .group-hover\\:scale-100 {
              transform: scale(1) !important;
            }
            .group:hover .group-hover\\:opacity-0 {
              opacity: 0 !important;
            }
          `}
        </style>
      </section>
      {/* دعوة للتسجيل بشكل بارز */}
      <section className="py-16 bg-gradient-to-r from-[#00B6F0] via-[#009ee3] to-[#0077b6] text-white text-center">
        <div className="max-w-2xl mx-auto space-y-8">
          <h2 className="text-4xl font-extrabold mb-2 text-white">جاهز تبدأ رحلتك التعليمية؟</h2>
          <p className="text-lg text-white/80">انضم الآن واستمتع بتجربة تعليمية متكاملة وسهلة.</p>
          <Button size="lg" className="bg-[#FFD600] text-[#0077b6] hover:bg-[#ffe066] px-10 py-4 rounded-xl font-bold text-xl border-2 border-[#00B6F0]" asChild>
            <Link to="/register">ابدأ اليوم</Link>
          </Button>
        </div>
      </section>
      {/* فوتر مبسط */}
      <footer className="py-8 bg-[#eaf6fb] text-center text-[#0077b6] text-sm">
        © 2025 منصة النخبة. جميع الحقوق محفوظة.
      </footer>
    </div>
  );
}