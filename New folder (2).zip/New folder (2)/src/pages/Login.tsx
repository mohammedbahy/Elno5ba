import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Mail, Lock, Phone, User } from 'lucide-react';

const FeatureCard = ({ 
  title, 
  description, 
  icon 
}: { 
  title: string; 
  description: string; 
  icon: React.ReactNode;
}) => (
  <Card className="border-2 border-border hover:border-edu-orange hover:shadow-lg edu-transition font-[Cairo,Tajawal,sans-serif]" dir="rtl">
    <CardHeader>
      <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-edu-yellow text-foreground">
        {icon}
      </div>
      <CardTitle className="text-xl text-edu-orange">{title}</CardTitle>
    </CardHeader>
    <CardContent>
      <CardDescription className="text-base">{description}</CardDescription>
    </CardContent>
  </Card>
);

export default function Login() {
  const navigate = useNavigate();
  const [userType, setUserType] = useState<'student' | 'teacher'>('student');
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Mock login function
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!identifier || !password) {
      setError('يرجى إدخال البريد الإلكتروني/رقم الهاتف وكلمة السر.');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      // Mock accounts
      const accounts = JSON.parse(localStorage.getItem('accounts') || '[]');
      const found = accounts.find(
        (acc: any) =>
          (acc.email === identifier || acc.phone === identifier) &&
          acc.password === password &&
          acc.role === userType
      );
      if (found) {
        // Save info and redirect
        localStorage.setItem(
          userType === 'student' ? 'student-info' : 'teacher-info',
          JSON.stringify(found)
        );
        if (userType === 'student') {
          navigate('/student-dashboard/select-subject');
        } else {
          navigate('/teacher-dashboard');
        }
      } else {
        setError('بيانات الدخول غير صحيحة أو نوع الحساب غير صحيح.');
      }
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#eaf6fb] via-[#d4ecf7] to-[#b3e0f7] font-[Cairo,Tajawal,sans-serif]">
      <div className="w-full max-w-md bg-white rounded-xl shadow-lg p-8 border-2 border-[#b3e0f7]">
        <h2 className="text-3xl font-bold text-[#0077b6] mb-6 text-center">تسجيل الدخول</h2>
        <div className="flex justify-center mb-6 gap-4">
          <button
            type="button"
            className={`px-6 py-2 rounded-xl font-bold border-2 transition-all duration-150 ${
              userType === 'student'
                ? 'bg-blue-500 text-white border-blue-600'
                : 'bg-white text-blue-700 border-blue-200 hover:bg-blue-50'
            }`}
            onClick={() => setUserType('student')}
          >
            طالب
          </button>
          <button
            type="button"
            className={`px-6 py-2 rounded-xl font-bold border-2 transition-all duration-150 ${
              userType === 'teacher'
                ? 'bg-blue-500 text-white border-blue-600'
                : 'bg-white text-blue-700 border-blue-200 hover:bg-blue-50'
            }`}
            onClick={() => setUserType('teacher')}
          >
            معلم
          </button>
        </div>
        <form onSubmit={handleLogin} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <div>
            <Label htmlFor="identifier" className="flex items-center gap-2 text-blue-700 mb-1 text-lg">
              <User className="text-blue-400" size={20} /> البريد الإلكتروني أو رقم الهاتف
            </Label>
            <Input
              id="identifier"
              type="text"
              placeholder="البريد الإلكتروني أو رقم الهاتف"
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition"
              autoComplete="username"
            />
          </div>
          <div>
            <Label htmlFor="password" className="flex items-center gap-2 text-blue-700 mb-1 text-lg">
              <Lock className="text-blue-400" size={20} /> كلمة السر
            </Label>
            <Input
              id="password"
              type="password"
              placeholder="كلمة السر"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition"
              autoComplete="current-password"
            />
          </div>
          <Button
            type="submit"
            className="w-full bg-[#00B6F0] hover:bg-[#009ee3] text-white font-bold py-3 rounded-xl mt-4 transition-all border-2 border-[#b3e0f7]"
            disabled={loading}
          >
            {loading ? 'جاري تسجيل الدخول...' : 'تسجيل الدخول'}
          </Button>
        </form>
        <div className="text-center mt-4 text-sm">
          ليس لديك حساب؟{' '}
          <a href="/register" className="text-blue-600 font-bold hover:underline">
            أنشئ حساب جديد
          </a>
        </div>
      </div>
    </div>
  );
}