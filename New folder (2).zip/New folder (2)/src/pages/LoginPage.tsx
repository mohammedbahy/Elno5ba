import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '@/App';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Phone, Lock } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function LoginPage() {
  const navigate = useNavigate();
  const { user, login, isLoading } = useAuth();
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // حفظ بيانات الحسابات المسجلة محلياً
  const saveAccount = (email: string, password: string, role: 'student' | 'teacher') => {
    let accounts = JSON.parse(localStorage.getItem('accounts') || '[]');
    // لا تكرر الحساب إذا كان موجود
    if (!accounts.find((acc: any) => acc.email === email)) {
      accounts.push({ email, password, role });
      localStorage.setItem('accounts', JSON.stringify(accounts));
    }
  };

  // تعديل login ليبحث في الحسابات المسجلة
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!phone || !password) {
      setError('يرجى إدخال رقم الهاتف وكلمة السر.');
      return;
    }
    // تحقق من الحسابات المسجلة محلياً أولاً
    const accounts = JSON.parse(localStorage.getItem('accounts') || '[]');
    const found = accounts.find(
      (acc: any) => (acc.email === phone || acc.phone === phone) && acc.password === password
    );
    if (found) {
      // تسجيل الدخول يدوي (محاكاة)
      await login(found.email, found.password);
      // إذا كان طالب، احفظ بيانات الطالب في localStorage
      if (found.role === 'student') {
        localStorage.setItem('student-info', JSON.stringify(found));
        navigate('/student-dashboard/select-subject');
      } else if (found.role === 'teacher') {
        navigate('/teacher-dashboard');
      }
      return;
    }
    // إذا لم يوجد، جرب الطريقة القديمة (الديمو)
    const success = await login(phone, password);
    if (success) {
      // إذا كان طالب ديمو، احفظ بيانات تجريبية
      if (!phone.includes('teacher')) {
        localStorage.setItem('student-info', JSON.stringify({ email: phone, role: 'student' }));
        navigate('/student-dashboard/select-subject');
      } else {
        navigate('/teacher-dashboard');
      }
    } else {
      setError('رقم الهاتف أو كلمة السر غير صحيح. حاول مرة أخرى.');
    }
  };

  // Demo login for student/teacher
  const handleDemoLogin = async (role: 'student' | 'teacher') => {
    setError('');
    if (role === 'student') {
      await login('student@example.com', '123456');
    } else {
      await login('teacher@example.com', '123456');
    }
  };

  // If user is already logged in, redirect to appropriate dashboard
  if (user) {
    if (user.role === 'student') {
      // إعادة التوجيه إلى اختيار المادة وليس الداشبورد مباشرة
      return <Navigate to="/student-dashboard/select-subject" replace />;
    } else if (user.role === 'teacher') {
      return <Navigate to="/teacher-dashboard" replace />;
    }
  }

  return (
    <div
      className="relative min-h-screen w-full flex items-center justify-center overflow-hidden"
      style={{
        fontFamily: 'Cairo,Tajawal,sans-serif',
        direction: 'rtl',
        background: 'linear-gradient(135deg, #2563eb 0%, #60a5fa 100%)',
        animation: 'gradientMove 8s ease-in-out infinite alternate'
      }}
    >
      {/* دوائر متحركة بالخلفية */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden z-0">
        <div className="absolute bg-blue-300 opacity-30 rounded-full animate-pulse"
          style={{ width: 400, height: 400, top: -100, left: -100, filter: 'blur(60px)' }} />
        <div className="absolute bg-blue-200 opacity-20 rounded-full animate-pulse"
          style={{ width: 300, height: 300, bottom: -80, right: -80, filter: 'blur(40px)' }} />
        <div className="absolute bg-cyan-300 opacity-20 rounded-full animate-pulse"
          style={{ width: 200, height: 200, bottom: 100, left: 100, filter: 'blur(30px)' }} />
      </div>
      {/* الفورم مع التبويبات */}
      <div className="relative z-10 w-full max-w-lg bg-white/90 rounded-2xl shadow-2xl p-10 flex flex-col items-center animate-fadeIn">
        <Tabs defaultValue="login" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="login">تسجيل الدخول</TabsTrigger>
            <TabsTrigger value="demo">دخول تجريبي</TabsTrigger>
          </TabsList>
          <TabsContent value="login">
            <h2 className="text-4xl font-extrabold text-blue-700 mb-2 text-center drop-shadow">تسجيل الدخول</h2>
            <p className="mb-8 text-gray-600 text-center text-lg font-medium">
              ادخل رقم الهاتف وكلمة المرور للدخول إلى حسابك
            </p>
            <form onSubmit={handleLogin} className="space-y-6 w-full">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              <div>
                <Label htmlFor="phone" className="flex items-center gap-2 text-blue-700 mb-1 text-lg">
                  <Phone className="text-blue-400" size={20} /> رقم الهاتف
                </Label>
                <Input
                  id="phone"
                  type="text"
                  placeholder="رقم الهاتف"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition"
                />
              </div>
              <div>
                <Label htmlFor="password" className="flex items-center gap-2 text-blue-700 mb-1 text-lg">
                  <Lock className="text-blue-400" size={20} /> كلمة السر
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="كلمة السر"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition"
                />
              </div>
              <Button
                type="submit"
                className="w-full bg-gradient-to-l from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 text-white text-lg font-bold py-2 rounded-xl shadow-lg transition-all duration-200"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    جاري تسجيل الدخول...
                  </>
                ) : 'تسجيل الدخول'}
              </Button>
            </form>
            <div className="w-full flex flex-col items-center mt-6">
              <Button
                type="button"
                className="w-full bg-white border border-blue-200 text-blue-700 font-bold py-2 rounded-xl shadow hover:bg-blue-50 transition mb-2"
                onClick={() => window.open('https://your-payment-link.com', '_blank')}
              >
                طريقة الدفع و الإشتراك في المواد
              </Button>
              <a href="#" className="text-blue-500 hover:underline font-bold mt-2 transition">هل نسيت كلمة السر؟</a>
            </div>
          </TabsContent>
          <TabsContent value="demo">
            <div className="space-y-4 py-2">
              <p className="text-sm text-muted-foreground text-center">
                استخدم أحد هذه الحسابات التجريبية لاستكشاف المنصة:
              </p>
              <div className="grid gap-4">
                <Button
                  onClick={() => handleDemoLogin('student')}
                  variant="outline"
                  className="w-full border-blue-400 text-blue-700 hover:bg-blue-50"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      جاري تسجيل الدخول...
                    </>
                  ) : 'دخول كطالب'}
                </Button>
                <Button
                  onClick={() => handleDemoLogin('teacher')}
                  variant="outline"
                  className="w-full border-cyan-400 text-blue-700 hover:bg-cyan-50"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      جاري تسجيل الدخول...
                    </>
                  ) : 'دخول كمعلم'}
                </Button>
              </div>
              <div className="rounded-md bg-slate-50 p-3 mt-2">
                <div className="grid gap-1">
                  <p className="font-medium text-sm">بيانات الطالب</p>
                  <p className="text-xs text-slate-500">student@example.com / 123456</p>
                </div>
                <div className="mt-2 grid gap-1">
                  <p className="font-medium text-sm">بيانات المعلم</p>
                  <p className="text-xs text-slate-500">teacher@example.com / 123456</p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
      {/* أنيميشن CSS */}
      <style>
        {`
        @keyframes gradientMove {
          0% { background-position: 0% 50%; }
          100% { background-position: 100% 50%; }
        }
        .animate-fadeIn {
          animation: fadeIn 1.2s cubic-bezier(.39,.575,.565,1) both;
        }
        @keyframes fadeIn {
          0% { opacity: 0; transform: translateY(40px);}
          100% { opacity: 1; transform: none;}
        }
        `}
      </style>
    </div>
  );
}