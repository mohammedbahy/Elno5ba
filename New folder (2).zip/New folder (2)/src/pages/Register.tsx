import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Link } from 'react-router-dom';

const FeatureCard = ({ 
  title, 
  description, 
  icon 
}: { 
  title: string; 
  description: string; 
  icon: React.ReactNode;
}) => (
  <Card className="border-2 border-border hover:border-edu-orange hover:shadow-lg edu-transition font-[Cairo,Tajawal,sans-serif]" dir="rtl">
    <CardHeader>
      <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-edu-yellow text-foreground">
        {icon}
      </div>
      <CardTitle className="text-xl text-edu-orange">{title}</CardTitle>
    </CardHeader>
    <CardContent>
      <CardDescription className="text-base">{description}</CardDescription>
    </CardContent>
  </Card>
);

export default function Register() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#eaf6fb] via-[#d4ecf7] to-[#b3e0f7] font-[Cairo,Tajawal,sans-serif]">
      <div className="w-full max-w-md bg-white rounded-xl shadow-lg p-8 border-2 border-[#b3e0f7]">
        <h2 className="text-3xl font-bold text-[#0077b6] mb-6 text-center">إنشاء حساب جديد</h2>
        {/* ...existing form fields... */}
        <button
          type="submit"
          className="w-full bg-[#00B6F0] hover:bg-[#009ee3] text-white font-bold py-3 rounded-xl mt-4 transition-all border-2 border-[#b3e0f7]"
        >
          إنشاء الحساب
        </button>
        {/* ...existing code... */}
      </div>
    </div>
  );
}