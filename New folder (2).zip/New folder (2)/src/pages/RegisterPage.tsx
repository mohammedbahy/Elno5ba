import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Mail, Lock, User, Phone, Book } from 'lucide-react';
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/App";

export default function RegisterPage() {
  const [form, setForm] = useState({
    firstName: '',
    secondName: '',
    thirdName: '',
    phone: '',
    guardianPhone: '',
    guardianJob: '',
    grade: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [userType, setUserType] = useState<'student' | 'teacher'>('student');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { login } = useAuth();

  // حفظ بيانات الحسابات المسجلة محلياً
  const saveAccount = (email: string, password: string, role: 'student' | 'teacher', phone?: string) => {
    let accounts = JSON.parse(localStorage.getItem('accounts') || '[]');
    // لا تكرر الحساب إذا كان موجود
    if (!accounts.find((acc: any) => acc.email === email)) {
      accounts.push({ email, password, role, phone });
      localStorage.setItem('accounts', JSON.stringify(accounts));
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // تحقق من الحقول المطلوبة حسب نوع المستخدم
    if (userType === 'student') {
      if (
        !form.firstName ||
        !form.secondName ||
        !form.thirdName ||
        !form.phone ||
        !form.guardianPhone ||
        !form.guardianJob ||
        !form.grade ||
        !form.email ||
        !form.password ||
        !form.confirmPassword
      ) {
        setError('يرجى إدخال جميع البيانات.');
        return;
      }
    } else {
      // teacher
      if (
        !form.firstName ||
        !form.secondName ||
        !form.thirdName ||
        !form.phone ||
        !form.email ||
        !form.password ||
        !form.confirmPassword
      ) {
        setError('يرجى إدخال جميع البيانات.');
        return;
      }
    }
    if (form.password !== form.confirmPassword) {
      setError('كلمة السر وتأكيدها غير متطابقين.');
      return;
    }

    setLoading(true);

    // محاكاة استدعاء API
    setTimeout(async () => {
      saveAccount(form.email, form.password, userType, form.phone);
      setSuccess('تم إنشاء الحساب بنجاح! سيتم تحويلك للمنصة...');
      setLoading(false);
      setTimeout(async () => {
        const accounts = JSON.parse(localStorage.getItem('accounts') || '[]');
        const found = accounts.find(
          (acc: any) =>
            (acc.email === form.email || acc.phone === form.phone) &&
            acc.password === form.password
        );
        if (found) {
          await login(found.email, found.password);
          localStorage.setItem(
            userType === 'student' ? 'student-info' : 'teacher-info',
            JSON.stringify(found)
          );
          if (userType === 'student') {
            window.location.href = "/student-dashboard/select-subject";
          } else {
            window.location.href = "/teacher-dashboard";
          }
        } else {
          setError("حدث خطأ أثناء تسجيل الدخول التلقائي.");
        }
      }, 1200);
    }, 1200);
  };

  return (
    <div
      className="min-h-screen w-full flex flex-col md:flex-row"
      style={{
        fontFamily: 'Cairo,Tajawal,sans-serif',
        direction: 'rtl',
        background: 'linear-gradient(120deg, #3b82f6 0%, #60a5fa 60%, #a5b4fc 100%)',
      }}
    >
      {/* صورة جانبية - تملأ العمود بالكامل */}
      <div
        className="hidden md:flex w-1/2 h-screen items-center justify-center relative"
        style={{
          background: 'linear-gradient(120deg, #3b82f6 0%, #60a5fa 60%, #a5b4fc 100%)',
        }}
      >
        <img
          src="https://i.postimg.cc/3x0F5j0t/2247683-removebg-preview-1.png"
          alt="تسجيل حساب جديد"
          className="w-full h-full object-cover object-center"
          style={{
            borderRadius: '0 2rem 2rem 0',
            boxShadow: '0 0 40px 0 #2563eb33',
          }}
        />
      </div>
      {/* الفورم - يملأ العمود بالكامل */}
      <div className="w-full md:w-1/2 h-screen flex flex-col justify-center items-center bg-white/90">
        <div className="w-full h-full flex flex-col justify-center items-center px-4 md:px-16">
          <div className="w-full max-w-xl">
            <h2 className="text-4xl font-bold text-blue-700 mb-4 text-center drop-shadow">طلب إنشاء حساب جديد</h2>
            <p className="mb-8 text-gray-600 text-center text-lg">
              يرجى إدخال بياناتك بشكل صحيح وسيتم التواصل معك لتفعيل الحساب
            </p>
            {/* نوع الحساب */}
            <div className="flex justify-center mb-6 gap-4">
              <button
                type="button"
                className={`px-6 py-2 rounded-xl font-bold border-2 transition-all duration-150 ${
                  userType === 'student'
                    ? 'bg-blue-500 text-white border-blue-600'
                    : 'bg-white text-blue-700 border-blue-200 hover:bg-blue-50'
                }`}
                onClick={() => setUserType('student')}
              >
                طالب
              </button>
              <button
                type="button"
                className={`px-6 py-2 rounded-xl font-bold border-2 transition-all duration-150 ${
                  userType === 'teacher'
                    ? 'bg-blue-500 text-white border-blue-600'
                    : 'bg-white text-blue-700 border-blue-200 hover:bg-blue-50'
                }`}
                onClick={() => setUserType('teacher')}
              >
                معلم
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-5">
              {error && (
                <Alert variant="destructive">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              {success && (
                <Alert variant="default">
                  <AlertDescription>{success}</AlertDescription>
                </Alert>
              )}
              {/* الاسم بالكامل في سطر واحد */}
              <div>
                <Label className="flex items-center gap-2 text-blue-700 mb-1">
                  <User className="text-blue-400" size={18} /> الاسم بالكامل 
                </Label>
                <div className="flex flex-row gap-2">
                  <Input
                    name="firstName"
                    type="text"
                    placeholder="الاسم الأول"
                    value={form.firstName}
                    onChange={handleChange}
                    className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition flex-1"
                  />
                  <Input
                    name="secondName"
                    type="text"
                    placeholder="الاسم الثاني"
                    value={form.secondName}
                    onChange={handleChange}
                    className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition flex-1"
                  />
                  <Input
                    name="thirdName"
                    type="text"
                    placeholder="الاسم الثالث"
                    value={form.thirdName}
                    onChange={handleChange}
                    className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition flex-1"
                  />
                </div>
              </div>
              {/* رقم الهاتف و رقم ولي الأمر في صف واحد */}
              <div className="flex flex-row gap-2">
                <div className="flex-1">
                  <Label htmlFor="phone" className="flex items-center gap-2 text-blue-700 mb-1">
                    <Phone className="text-blue-400" size={18} /> رقم الهاتف
                  </Label>
                  <Input
                    id="phone"
                    name="phone"
                    type="text"
                    value={form.phone}
                    onChange={handleChange}
                    className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition"
                  />
                </div>
                {userType === 'student' && (
                  <div className="flex-1">
                    <Label htmlFor="guardianPhone" className="flex items-center gap-2 text-blue-700 mb-1">
                      <Phone className="text-blue-400" size={18} /> رقم هاتف ولي الأمر
                    </Label>
                    <Input
                      id="guardianPhone"
                      name="guardianPhone"
                      type="text"
                      value={form.guardianPhone}
                      onChange={handleChange}
                      className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition"
                    />
                  </div>
                )}
              </div>
              {/* مهنة ولي الأمر والصف الدراسي في صف واحد */}
              {userType === 'student' && (
                <div className="flex flex-row gap-2">
                  <div className="flex-1">
                    <Label htmlFor="guardianJob" className="flex items-center gap-2 text-blue-700 mb-1">
                      <User className="text-blue-400" size={18} /> مهنة ولي الأمر
                    </Label>
                    <Input
                      id="guardianJob"
                      name="guardianJob"
                      type="text"
                      value={form.guardianJob}
                      onChange={handleChange}
                      className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition"
                    />
                  </div>
                  <div className="flex-1">
                    <Label htmlFor="grade" className="flex items-center gap-2 text-blue-700 mb-1">
                      <Book className="text-blue-400" size={18} /> الصف الدراسي
                    </Label>
                    <select
                      id="grade"
                      name="grade"
                      value={form.grade}
                      onChange={handleChange}
                      className="w-full rounded-md border border-blue-200 bg-blue-50 py-2 px-3 text-right focus:outline-none focus:ring-2 focus:ring-blue-400 transition"
                      aria-label="الصف الدراسي"
                    >
                      <option value="">اختر الصف</option>
                      <option value="الأول الثانوي">الصف الأول الثانوي</option>
                      <option value="الثاني الثانوي">الصف الثاني الثانوي</option>
                      <option value="الثالث الثانوي">الصف الثالث الثانوي</option>
                    </select>
                  </div>
                </div>
              )}
              {/* البريد الإلكتروني */}
              <div>
                <Label htmlFor="email" className="flex items-center gap-2 text-blue-700 mb-1">
                  <Mail className="text-blue-400" size={18} /> البريد الإلكتروني
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="your-email@example.com"
                  value={form.email}
                  onChange={handleChange}
                  className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition"
                />
              </div>
              {/* كلمة السر وتأكيدها في صف واحد */}
              <div className="flex flex-row gap-2">
                <div className="flex-1">
                  <Label htmlFor="password" className="flex items-center gap-2 text-blue-700 mb-1">
                    <Lock className="text-blue-400" size={18} /> كلمة السر
                  </Label>
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    value={form.password}
                    onChange={handleChange}
                    className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition"
                  />
                </div>
                <div className="flex-1">
                  <Label htmlFor="confirmPassword" className="flex items-center gap-2 text-blue-700 mb-1">
                    <Lock className="text-blue-400" size={18} /> تأكيد كلمة السر
                  </Label>
                  <Input
                    id="confirmPassword"
                    name="confirmPassword"
                    type="password"
                    value={form.confirmPassword}
                    onChange={handleChange}
                    className="text-right bg-blue-50 focus:bg-white focus:ring-2 focus:ring-blue-400 transition"
                  />
                </div>
              </div>
              {/* زر إنشاء الحساب مع مسافة للأسفل */}
              <div className="pt-4">
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-l from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 text-white text-lg font-bold py-2 rounded-xl shadow-lg transition-all duration-200"
                  disabled={loading}
                >
                  {loading ? "جاري إنشاء الحساب..." : "إنشاء حساب"}
                </Button>
              </div>
              <div className="text-center mt-4 text-sm">
                لديك حساب بالفعل؟{' '}
                <a href="/login" className="text-blue-600 font-bold hover:underline">
                  سجل الدخول الآن
                </a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}