import { useState } from 'react';
import { useAuth } from '@/App';
import { Routes, useNavigate, Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Calendar,
  Clock,
  Video,
  BookOpen,
  FileText,
  CreditCard,
  User,
  LogOut,
  Menu,
  X,
  Home,
  BarChart,
  Bell
} from 'lucide-react';

// Import Student Dashboard Components
import StudentDashboardHome from '@/components/student/StudentDashboardHome';
import LecturesComponent from '@/components/student/LecturesComponent';
import AttendanceComponent from '@/components/student/AttendanceComponent';
import ExamsComponent from '@/components/student/ExamsComponent';
import PaymentsComponent from '@/components/student/PaymentsComponent';
import ProfileComponent from '@/components/student/ProfileComponent';
import { Navigate, Route } from 'react-router-dom';
// import StudentSubjectSelect from '@/pages/StudentSubjectSelect';
import StudentSubjectSelect from '@/pages/StudentSubjectSelect';

export default function StudentDashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  // تحديد المادة المختارة من المسار
  // دعم جميع المواد في السايد بار
  const getSubjectFromPath = () => {
    if (location.pathname.includes('/physics')) return 'physics';
    if (location.pathname.includes('/chemistry')) return 'chemistry';
    if (location.pathname.includes('/biology')) return 'biology';
    if (location.pathname.includes('/science')) return 'science';
    if (location.pathname.includes('/arabic')) return 'arabic';
    if (location.pathname === '/student-dashboard/profile') {
      const cachedSubject = localStorage.getItem('student-dashboard-subject');
      return cachedSubject || 'physics';
    }
    return null;
  };

  const subject = getSubjectFromPath();

  if (subject) {
    localStorage.setItem('student-dashboard-subject', subject);
  }

  const navItems = subject
    ? [
        { name: "الرئيسية", path: `/student-dashboard/${subject}`, icon: <Home className="h-8 w-8" /> },
        { name: "المحاضرات", path: `/student-dashboard/${subject}/lectures`, icon: <Video className="h-8 w-8" /> },
        { name: "الحضور", path: `/student-dashboard/${subject}/attendance`, icon: <Calendar className="h-8 w-8" /> },
        { name: "الامتحانات", path: `/student-dashboard/${subject}/exams`, icon: <FileText className="h-8 w-8" /> },
        { name: "المدفوعات", path: `/student-dashboard/${subject}/payments`, icon: <CreditCard className="h-8 w-8" /> },
        { name: "الملف الشخصي", path: `/student-dashboard/profile`, icon: <User className="h-8 w-8" /> },
      ]
    : [];
  
  const isActive = (path: string) => {
    if (path === '/student-dashboard' && location.pathname === '/student-dashboard') {
      return true;
    }
    if (path !== '/student-dashboard' && location.pathname.startsWith(path)) {
      return true;
    }
    return false;
  };
  
  return (
    <div
      className="flex h-screen bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-50 font-[Cairo,Tajawal,sans-serif]"
      dir="rtl"
      style={{
        background: 'linear-gradient(120deg, #f1f5fe 0%, #e0e7ff 60%, #fbc2eb 100%)',
      }}
    >
      {/* الشريط الجانبي - سطح المكتب */}
      <aside className="hidden md:flex flex-col w-64 bg-gradient-to-b from-indigo-900 via-purple-800 to-pink-700 text-white border-r border-pink-200 shadow-2xl rounded-r-3xl">
        <div className="flex items-center gap-2 px-6 py-4">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-pink-400 via-purple-400 to-indigo-400 flex items-center justify-center shadow-lg border-2 border-white">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
              <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
            </svg>
          </div>
          <h1 className="text-2xl font-extrabold text-white drop-shadow-lg">منصة التعليم</h1>
        </div>
        <ScrollArea className="flex-1 py-4">
          <nav className="space-y-2 px-3">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-2 rounded-xl font-semibold transition-all duration-150 ${
                  isActive(item.path) 
                    ? 'bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-400 text-white shadow-xl scale-105' 
                    : 'hover:bg-gradient-to-r hover:from-indigo-600 hover:via-purple-600 hover:to-pink-500 hover:text-white'
                }`}
              >
                {item.icon}
                <span>{item.name}</span>
                {item.name === "الرئيسية" && (
                  <Badge className="ml-auto bg-pink-200 text-indigo-900 shadow">جديد</Badge>
                )}
              </Link>
            ))}
          </nav>
        </ScrollArea>
        <div className="p-4 border-t border-pink-200">
          <Button
            variant="ghost"
            className="btn-animate w-full flex items-center gap-2 hover:bg-gradient-to-r hover:from-pink-500 hover:to-indigo-500 hover:text-white rounded-xl"
            onClick={handleLogout}
          >
            <LogOut className="h-5 w-5" />
            <span className="font-bold">تسجيل الخروج</span>
          </Button>
        </div>
      </aside>
      
      {/* زر القائمة للجوال */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-20 flex items-center justify-between p-4 bg-gradient-to-r from-indigo-800 via-purple-700 to-pink-600 border-b shadow-2xl">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-pink-400 via-purple-400 to-indigo-400 flex items-center justify-center shadow-lg border-2 border-white">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
              <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
            </svg>
          </div>
          <h1 className="text-2xl font-extrabold text-white drop-shadow-lg">منصة التعليم</h1>
        </div>
        <Button className="btn-animate"
          variant="ghost"
          size="icon"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? (
            <X className="h-6 w-6 text-white" />
          ) : (
            <Menu className="h-6 w-6 text-white" />
          )}
        </Button>
      </div>
      
      {/* قائمة الجوال */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-10 bg-indigo-900/70 backdrop-blur-sm">
          <aside className="fixed top-[65px] left-0 h-[calc(100vh-65px)] w-3/4 max-w-xs bg-gradient-to-b from-indigo-900 via-purple-800 to-pink-700 text-white shadow-2xl rounded-r-3xl">
            <ScrollArea className="h-full py-4">
              <nav className="space-y-2 px-3">
                {navItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`flex items-center gap-3 px-4 py-2 rounded-xl font-semibold transition-all duration-150 ${
                      isActive(item.path) 
                        ? 'bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-400 text-white shadow-xl scale-105' 
                        : 'hover:bg-gradient-to-r hover:from-indigo-600 hover:via-purple-600 hover:to-pink-500 hover:text-white'
                    }`}
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {item.icon}
                    <span>{item.name}</span>
                    {item.name === "الرئيسية" && (
                      <Badge className="ml-auto bg-pink-200 text-indigo-900 shadow">جديد</Badge>
                    )}
                  </Link>
                ))}
              </nav>
              <div className="p-4 mt-6 border-t border-pink-200">
                <Button
                  variant="ghost"
                  className="btn-animate w-full flex items-center gap-2 hover:bg-gradient-to-r hover:from-pink-500 hover:to-indigo-500 hover:text-white rounded-xl"
                  onClick={() => {
                    handleLogout();
                    setMobileMenuOpen(false);
                  }}
                >
                  <LogOut className="h-5 w-5" />
                  <span className="font-bold">تسجيل الخروج</span>
                </Button>
              </div>
            </ScrollArea>
          </aside>
        </div>
      )}
      
      {/* المحتوى الرئيسي */}
      <main className="flex-1 overflow-auto bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
        {/* الشريط العلوي - الإشعارات وقائمة المستخدم */}
        <header className="hidden md:flex items-center justify-between border-b bg-gradient-to-r from-indigo-100 via-purple-100 to-pink-100 p-4 shadow-lg rounded-bl-3xl">
          <div className="space-y-0.5">
            <h2 className="text-2xl font-extrabold tracking-tight text-indigo-800 drop-shadow">مرحباً، {user?.name}</h2>
            <p className="text-purple-500 font-medium">إدارة المحاضرات، الاختبارات، والتقدم الأكاديمي</p>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="icon" className="btn-animate border-pink-200 bg-white hover:bg-pink-50 shadow">
              <Bell className="h-[1.2rem] w-[1.2rem] text-pink-600" />
              <span className="sr-only">الإشعارات</span>
            </Button>
            {/* <Avatar>
              <AvatarImage src="/images/Profile.jpg" alt={user?.name} />
              <AvatarFallback className="bg-gradient-to-tr from-pink-400 via-purple-400 to-indigo-400 text-white">{user?.name?.charAt(0) ?? 'ط'}</AvatarFallback>
            </Avatar> */}
          </div>
        </header>
        {/* محتوى لوحة التحكم */}
        <div className="p-4 md:p-6">
          <Routes>
            {/* اختيار المادة */}
            <Route path="/" element={<Navigate to="/student-dashboard/select-subject" replace />} />
            <Route path="/select-subject" element={<StudentSubjectSelect />} />
            {/* فيزياء */}
            <Route path="/physics" element={<StudentDashboardHome />} />
            <Route path="/physics/lectures" element={<LecturesComponent />} />
            <Route path="/physics/attendance" element={<AttendanceComponent />} />
            <Route path="/physics/exams" element={<ExamsComponent />} />
            <Route path="/physics/payments" element={<PaymentsComponent />} />
            {/* كيمياء */}
            <Route path="/chemistry" element={<StudentDashboardHome />} />
            <Route path="/chemistry/lectures" element={<LecturesComponent />} />
            <Route path="/chemistry/attendance" element={<AttendanceComponent />} />
            <Route path="/chemistry/exams" element={<ExamsComponent />} />
            <Route path="/chemistry/payments" element={<PaymentsComponent />} />
            {/* أحياء */}
            <Route path="/biology" element={<StudentDashboardHome />} />
            <Route path="/biology/lectures" element={<LecturesComponent />} />
            <Route path="/biology/attendance" element={<AttendanceComponent />} />
            <Route path="/biology/exams" element={<ExamsComponent />} />
            <Route path="/biology/payments" element={<PaymentsComponent />} />
            {/* علوم متكاملة */}
            <Route path="/science" element={<StudentDashboardHome />} />
            <Route path="/science/lectures" element={<LecturesComponent />} />
            <Route path="/science/attendance" element={<AttendanceComponent />} />
            <Route path="/science/exams" element={<ExamsComponent />} />
            <Route path="/science/payments" element={<PaymentsComponent />} />
            {/* اللغة العربية */}
            <Route path="/arabic" element={<StudentDashboardHome />} />
            <Route path="/arabic/lectures" element={<LecturesComponent />} />
            <Route path="/arabic/attendance" element={<AttendanceComponent />} />
            <Route path="/arabic/exams" element={<ExamsComponent />} />
            <Route path="/arabic/payments" element={<PaymentsComponent />} />
            {/* الملف الشخصي عام */}
            <Route path="/profile" element={<ProfileComponent />} />
          </Routes>
        </div>
      </main>
    </div>
  );
}