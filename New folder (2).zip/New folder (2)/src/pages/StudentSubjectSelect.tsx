import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { FlaskConical, Atom, Feather, BookOpen, Languages } from 'lucide-react';

const subjects = [
	{
		name: 'الفيزياء',
		path: '/student-dashboard/physics',
		color: 'bg-edu-pink hover:bg-edu-pink/90 border-edu-pink/30 text-edu-purple',
		icon: <Atom className="w-24 h-24 mb-4 text-edu-purple drop-shadow-lg" />,
	},
	{
		name: 'الكيمياء',
		path: '/student-dashboard/chemistry',
		color: 'bg-edu-yellow hover:bg-edu-yellow/90 border-edu-yellow/30 text-edu-orange',
		icon: <FlaskConical className="w-24 h-24 mb-4 text-edu-orange drop-shadow-lg" />,
	},
	{
		name: 'الأحياء',
		path: '/student-dashboard/biology',
		color: 'bg-green-100 hover:bg-green-200 border-green-200 text-green-700',
		icon: <Feather className="w-24 h-24 mb-4 text-green-500 drop-shadow-lg" />,
	},
	{
		name: 'علوم متكاملة',
		path: '/student-dashboard/science',
		color: 'bg-cyan-100 hover:bg-cyan-200 border-cyan-200 text-cyan-700',
		icon: <BookOpen className="w-24 h-24 mb-4 text-cyan-500 drop-shadow-lg" />,
	},
	{
		name: 'اللغة العربية',
		path: '/student-dashboard/arabic',
		color: 'bg-yellow-200 hover:bg-yellow-300 border-yellow-300 text-yellow-700',
		icon: <Languages className="w-24 h-24 mb-4 text-yellow-500 drop-shadow-lg" />,
	},
];

export default function StudentSubjectSelect() {
	const navigate = useNavigate();
	return (
		<div
			className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-edu-pink/10 via-white to-edu-yellow/10 px-0"
			dir="rtl"
		>
			<div className="w-full max-w-[1600px] mx-auto py-12 px-2 md:px-10">
				<h2 className="text-5xl md:text-6xl font-extrabold text-edu-purple mb-8 flex items-center gap-4 justify-center animate-fade-in">
					<span>اختر المادة الدراسية</span>
					<span className="animate-bounce">🎓</span>
				</h2>
				<p className="text-muted-foreground text-2xl mb-10 text-center animate-fade-in delay-100">
					يرجى اختيار المادة التي ترغب في متابعتها
				</p>
				<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-10 w-full animate-fade-in delay-200">
					{subjects.map((subject, idx) => (
						<div key={subject.name} className="w-full">
							<Button
								className={`btn-animate flex flex-col items-center gap-3 ${subject.color} text-3xl md:text-4xl px-0 py-20 rounded-[2.5rem] shadow-2xl border-2 w-full transition-all duration-300 hover:scale-[1.07] hover:shadow-edu-pink/40 animate-pop-in`}
								style={{
									animationDelay: `${idx * 0.1 + 0.2}s`,
									animationDuration: '0.7s',
								}}
								onClick={() => navigate(subject.path + '/')}
							>
								{subject.icon}
								<span className="font-extrabold">{subject.name}</span>
							</Button>
						</div>
					))}
				</div>
			</div>
			<style>{`
				@keyframes pop-in {
					0% { transform: scale(0.8); opacity: 0; }
					100% { transform: scale(1); opacity: 1; }
				}
				.animate-pop-in {
					animation: pop-in 0.7s cubic-bezier(.22,1,.36,1) both;
				}
				@keyframes fade-in {
					from { opacity: 0; }
					to { opacity: 1; }
				}
				.animate-fade-in {
					animation: fade-in 1s both;
				}
				.animate-fade-in.delay-100 { animation-delay: 0.1s; }
				.animate-fade-in.delay-200 { animation-delay: 0.2s; }
			`}</style>
		</div>
	);
}
